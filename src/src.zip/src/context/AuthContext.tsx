import React, { createContext, useState, useEffect, useContext, useCallback } from 'react';
import jwtDecode from 'jwt-decode';

interface User {
  email: string; // Utiliser l'email comme identifiant unique
  firstname: string;
  lastname: string;
  // L'ID n'est plus directement extrait ici, mais l'email est suffisant pour l'identification
}

interface AuthContextType {
  isAuthenticated: boolean;
  user: User | null;
  login: (token: string) => void;
  logout: () => void;
}

export const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [user, setUser] = useState<User | null>(null);

  const decodeAndSetUser = useCallback((token: string) => {
    try {
      const decodedToken: { sub: string; firstname: string; lastname: string } = jwtDecode(token);
      const user: User = {
        email: decodedToken.sub,
        firstname: decodedToken.firstname,
        lastname: decodedToken.lastname,
      };
      setIsAuthenticated(true);
      setUser(user);
      return true;
    } catch (error) {
      console.error("Failed to decode token:", error);
      localStorage.removeItem('token');
      setIsAuthenticated(false);
      setUser(null);
      return false;
    }
  }, []);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      decodeAndSetUser(token);
    }
  }, [decodeAndSetUser]);

  const login = useCallback((token: string) => {
    localStorage.setItem('token', token);
    decodeAndSetUser(token);
  }, [decodeAndSetUser]);

  const logout = useCallback(() => {
    localStorage.removeItem('token');
    setIsAuthenticated(false);
    setUser(null);
  }, []);

  return (
    <AuthContext.Provider value={{ isAuthenticated, user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
