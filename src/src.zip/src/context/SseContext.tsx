import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { useAuth } from './AuthContext';
import { fetchEventSource } from '@microsoft/fetch-event-source';
import api from '../services/api';

interface MessagePayload {
  id: number;
  senderId: number;
  projectId: number;
  isRead: boolean;
  // ... autres champs de message
}

interface SseContextType {
  projectUnreadCounts: Map<number, number>;
  newInvitation: boolean;
  messagesByProject: Map<number, MessagePayload[]>; // Nouvelle carte de messages
  clearNewInvitation: () => void;
}

const SseContext = createContext<SseContextType | undefined>(undefined);

export const SseProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isAuthenticated } = useAuth();
  const [projectUnreadCounts, setProjectUnreadCounts] = useState<Map<number, number>>(new Map());
  const [newInvitation, setNewInvitation] = useState(false);
  const [messagesByProject, setMessagesByProject] = useState<Map<number, MessagePayload[]>>(new Map());

  // Charger les compteurs initiaux par projet au login
  useEffect(() => {
    if (isAuthenticated) {
      api.get<Record<string, number>>('/messages/count/unread-per-project')
        .then(response => {
          const newMap = new Map<number, number>();
          for (const key in response.data) {
            newMap.set(Number(key), response.data[key]);
          }
          setProjectUnreadCounts(newMap);
        })
        .catch(error => console.error("Failed to fetch initial unread counts per project:", error));
    }
  }, [isAuthenticated]);

  // Établir la connexion SSE une seule fois
  useEffect(() => {
    if (!isAuthenticated) return;

    const token = localStorage.getItem('token');
    if (!token) return;

    const ctrl = new AbortController();

    fetchEventSource(`http://localhost:8080/api/sse/subscribe?token=${token}`, {
      signal: ctrl.signal,
      onopen: () => console.log('Global SSE Connection Opened!'),
      onerror: (err) => {
        console.error('Global SSE Error:', err);
        throw err;
      },
      onmessage(ev) {
        if (ev.event === 'newMessage') {
          const receivedMessage = JSON.parse(ev.data);
          setMessagesByProject(prev => {
            const newMap = new Map(prev);
            const projectMessages = newMap.get(receivedMessage.projectId) || [];
            if (!projectMessages.some(msg => msg.id === receivedMessage.id)) {
              newMap.set(receivedMessage.projectId, [...projectMessages, receivedMessage]);
            }
            return newMap;
          });
        } else if (ev.event === 'projectUnreadCountUpdate') {
          const data = JSON.parse(ev.data);
          setProjectUnreadCounts(prev => new Map(prev).set(data.projectId, data.count));
        } else if (ev.event === 'newInvitation') {
          setNewInvitation(true);
        } else if (ev.event === 'messagesReadUpdate') {
          const data = JSON.parse(ev.data);
          setMessagesByProject(prev => {
            const newMap = new Map(prev);
            const projectMessages = newMap.get(data.projectId) || [];
            newMap.set(data.projectId, projectMessages.map(msg => ({ ...msg, isRead: true })));
            return newMap;
          });
        }
      },
    });

    return () => ctrl.abort();
  }, [isAuthenticated]);

  const clearNewInvitation = () => {
    setNewInvitation(false);
  };

  return (
    <SseContext.Provider value={{ projectUnreadCounts, newInvitation, messagesByProject, clearNewInvitation }}>
      {children}
    </SseContext.Provider>
  );
};

export const useSse = () => {
  const context = useContext(SseContext);
  if (context === undefined) {
    throw new Error('useSse must be used within an SseProvider');
  }
  return context;
};
