import React, { useState } from 'react';
import { useForm, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';
import { Loader2, ArrowLeft, PlusCircle, Trash2, Rocket, Calendar, Users, FileText } from 'lucide-react';

// Mise à jour du schéma pour la collaboration
const projectSchema = z.object({
  name: z.string().min(3, { message: 'Le nom du projet doit contenir au moins 3 caractères.' }),
  description: z.string().optional(),
  numberOfSprints: z.coerce.number().min(1, { message: 'Il doit y avoir au moins 1 sprint.' }).max(20, { message: 'Maximum 20 sprints.' }),
  sprintDurationInDays: z.coerce.number().min(7, { message: 'Un sprint doit durer au moins 7 jours.' }).max(30, { message: 'Un sprint ne peut pas dépasser 30 jours.' }),
  memberEmails: z.array(z.object({ email: z.string().email({ message: 'Email invalide.' }) })).optional(),
  supervisorEmail: z.string().email({ message: 'Email invalide.' }).optional().or(z.literal('')),
});

type ProjectFormInputs = z.infer<typeof projectSchema>;

const CreateProjectPage: React.FC = () => {
  const navigate = useNavigate();
  const [serverError, setServerError] = useState<string | null>(null);

  const {
    register,
    control,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<ProjectFormInputs>({
    resolver: zodResolver(projectSchema),
    defaultValues: {
      sprintDurationInDays: 14,
      memberEmails: [],
    },
  });

  const { fields, append, remove } = useFieldArray({
    control,
    name: "memberEmails",
  });

  const onSubmit = async (data: ProjectFormInputs) => {
    try {
      setServerError(null);
      // Transformer les données pour correspondre au DTO du backend
      const requestData = {
        ...data,
        memberEmails: data.memberEmails?.map(m => m.email),
      };
      await api.post('/projects', requestData);
      navigate('/dashboard');
    } catch (error: any) {
      setServerError(error.response?.data?.message || "Une erreur s'est produite lors de la création du projet.");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-purple-50 to-indigo-50 p-6">
      {/* Background animated elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute w-96 h-96 -top-48 -left-48 bg-purple-300 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse"></div>
        <div className="absolute w-96 h-96 -bottom-48 -right-48 bg-blue-300 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse"></div>
      </div>

      <div className="relative max-w-5xl mx-auto">
        {/* Header */}
        <div className="flex items-center mb-8">
          <button 
            onClick={() => navigate(-1)} 
            className="flex items-center justify-center p-3 rounded-2xl bg-white/80 backdrop-blur-sm border border-gray-200 hover:bg-white hover:shadow-lg transition-all duration-300 mr-4 group"
          >
            <ArrowLeft className="h-6 w-6 text-gray-600 group-hover:text-gray-900 transition-colors" />
          </button>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Rocket className="h-7 w-7 text-purple-500" />
              <h1 className="text-4xl font-bold bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
                Créer un nouveau projet
              </h1>
            </div>
            <p className="text-gray-600 text-sm">Définissez les paramètres de votre projet</p>
          </div>
        </div>
        
        {/* Form Container */}
        <div className="bg-white/80 backdrop-blur-xl p-8 rounded-3xl border border-gray-100 shadow-2xl">
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
            {serverError && (
              <div className="p-4 text-sm text-red-700 bg-red-50 rounded-2xl border border-red-200 backdrop-blur-sm">
                {serverError}
              </div>
            )}

            {/* Informations de base */}
            <div className="space-y-6">
              <div className="flex items-center gap-3 pb-3 border-b border-gray-200">
                <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center shadow-lg shadow-purple-500/30">
                  <FileText className="h-5 w-5 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900">Informations Générales</h3>
              </div>

              <div>
                <label htmlFor="name" className="block mb-2 font-medium text-gray-700">
                  Nom du projet <span className="text-pink-500">*</span>
                </label>
                <input 
                  id="name" 
                  {...register('name')} 
                  className={`w-full px-4 py-3 bg-white border rounded-2xl text-gray-900 placeholder-gray-400 backdrop-blur-sm focus:outline-none focus:ring-2 transition-all duration-300 ${
                    errors.name 
                      ? 'border-red-300 focus:ring-red-500/30 focus:border-red-500' 
                      : 'border-gray-200 focus:ring-purple-500/30 focus:border-purple-500 hover:border-gray-300'
                  }`}
                  placeholder="Mon projet innovant"
                />
                {errors.name && <p className="mt-2 text-sm text-red-600">{errors.name.message}</p>}
              </div>

              <div>
                <label htmlFor="description" className="block mb-2 font-medium text-gray-700">Description</label>
                <textarea 
                  id="description" 
                  {...register('description')} 
                  rows={4} 
                  className="w-full px-4 py-3 bg-white border border-gray-200 rounded-2xl text-gray-900 placeholder-gray-400 backdrop-blur-sm focus:outline-none focus:ring-2 focus:ring-purple-500/30 focus:border-purple-500 hover:border-gray-300 transition-all duration-300 resize-none"
                  placeholder="Décrivez votre projet..."
                />
              </div>
            </div>

            {/* Planification des Sprints */}
            <div className="space-y-6">
              <div className="flex items-center gap-3 pb-3 border-b border-gray-200">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/30">
                  <Calendar className="h-5 w-5 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900">Planification</h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="numberOfSprints" className="block mb-2 font-medium text-gray-700">
                    Nombre de Sprints <span className="text-pink-500">*</span>
                  </label>
                  <input 
                    id="numberOfSprints" 
                    type="number" 
                    {...register('numberOfSprints')} 
                    className={`w-full px-4 py-3 bg-white border rounded-2xl text-gray-900 placeholder-gray-400 backdrop-blur-sm focus:outline-none focus:ring-2 transition-all duration-300 ${
                      errors.numberOfSprints 
                        ? 'border-red-300 focus:ring-red-500/30 focus:border-red-500' 
                        : 'border-gray-200 focus:ring-purple-500/30 focus:border-purple-500 hover:border-gray-300'
                    }`}
                    placeholder="4"
                  />
                  {errors.numberOfSprints && <p className="mt-2 text-sm text-red-600">{errors.numberOfSprints.message}</p>}
                </div>

                <div>
                  <label htmlFor="sprintDurationInDays" className="block mb-2 font-medium text-gray-700">
                    Durée d'un sprint (jours) <span className="text-pink-500">*</span>
                  </label>
                  <input 
                    id="sprintDurationInDays" 
                    type="number" 
                    {...register('sprintDurationInDays')} 
                    className={`w-full px-4 py-3 bg-white border rounded-2xl text-gray-900 placeholder-gray-400 backdrop-blur-sm focus:outline-none focus:ring-2 transition-all duration-300 ${
                      errors.sprintDurationInDays 
                        ? 'border-red-300 focus:ring-red-500/30 focus:border-red-500' 
                        : 'border-gray-200 focus:ring-purple-500/30 focus:border-purple-500 hover:border-gray-300'
                    }`}
                    placeholder="14"
                  />
                  {errors.sprintDurationInDays && <p className="mt-2 text-sm text-red-600">{errors.sprintDurationInDays.message}</p>}
                </div>
              </div>
            </div>

            {/* Équipe (Optionnel) */}
            <div className="space-y-6">
              <div className="flex items-center gap-3 pb-3 border-b border-gray-200">
                <div className="w-10 h-10 bg-gradient-to-br from-pink-500 to-rose-500 rounded-xl flex items-center justify-center shadow-lg shadow-pink-500/30">
                  <Users className="h-5 w-5 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900">Équipe <span className="text-gray-500 text-sm font-normal">(Optionnel)</span></h3>
              </div>

              <div>
                <label htmlFor="supervisorEmail" className="block mb-2 font-medium text-gray-700">Email du Superviseur</label>
                <input 
                  id="supervisorEmail" 
                  {...register('supervisorEmail')} 
                  placeholder="professeur@exemple.com" 
                  className={`w-full px-4 py-3 bg-white border rounded-2xl text-gray-900 placeholder-gray-400 backdrop-blur-sm focus:outline-none focus:ring-2 transition-all duration-300 ${
                    errors.supervisorEmail 
                      ? 'border-red-300 focus:ring-red-500/30 focus:border-red-500' 
                      : 'border-gray-200 focus:ring-purple-500/30 focus:border-purple-500 hover:border-gray-300'
                  }`}
                />
                {errors.supervisorEmail && <p className="mt-2 text-sm text-red-600">{errors.supervisorEmail.message}</p>}
              </div>

              <div>
                <label className="block mb-3 font-medium text-gray-700">Emails des Membres</label>
                <div className="space-y-3">
                  {fields.map((field, index) => (
                    <div key={field.id} className="flex items-center gap-3 group">
                      <input
                        {...register(`memberEmails.${index}.email`)}
                        placeholder="etudiant@exemple.com"
                        className={`flex-1 px-4 py-3 bg-white border rounded-2xl text-gray-900 placeholder-gray-400 backdrop-blur-sm focus:outline-none focus:ring-2 transition-all duration-300 ${
                          errors.memberEmails?.[index]?.email 
                            ? 'border-red-300 focus:ring-red-500/30 focus:border-red-500' 
                            : 'border-gray-200 focus:ring-purple-500/30 focus:border-purple-500 hover:border-gray-300'
                        }`}
                      />
                      <button 
                        type="button" 
                        onClick={() => remove(index)} 
                        className="p-3 text-red-600 hover:text-red-700 bg-red-50 hover:bg-red-100 rounded-2xl border border-red-200 hover:border-red-300 transition-all duration-300"
                      >
                        <Trash2 size={20} />
                      </button>
                    </div>
                  ))}
                </div>
                
                <button
                  type="button"
                  onClick={() => append({ email: "" })}
                  className="flex items-center gap-2 text-sm text-purple-600 hover:text-purple-700 mt-4 px-4 py-2 rounded-xl bg-purple-50 hover:bg-purple-100 border border-purple-200 hover:border-purple-300 transition-all duration-300"
                >
                  <PlusCircle size={18} />
                  Ajouter un membre
                </button>
              </div>
            </div>

            {/* Submit Button */}
            <div className="flex justify-end pt-6 border-t border-gray-200">
              <button 
                type="submit" 
                disabled={isSubmitting} 
                className="group flex items-center justify-center bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-semibold py-3 px-8 rounded-2xl shadow-xl shadow-purple-500/30 hover:shadow-2xl hover:shadow-purple-500/40 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed relative overflow-hidden"
              >
                <span className="relative z-10 flex items-center">
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                      Création en cours...
                    </>
                  ) : (
                    <>
                      <Rocket className="mr-2 h-5 w-5" />
                      Créer le projet
                    </>
                  )}
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-indigo-700 to-purple-700 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default CreateProjectPage;