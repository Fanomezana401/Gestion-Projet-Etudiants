import React, { useEffect, useState } from 'react';
import api from '../services/api';
import { Loader2, Folder, CheckCircle, ListTodo, Flag, MessageSquare, BarChart2, TrendingUp, Target, Zap, Sparkles, Activity } from 'lucide-react';

interface Statistics {
  totalProjects: number;
  activeProjects: number;
  completedProjects: number;
  totalSprints: number;
  activeSprints: number;
  completedSprints: number;
  totalTasks: number;
  completedTasks: number;
  averageProjectProgress: number;
  unreadMessages: number;
}

const StatsPage: React.FC = () => {
  const [stats, setStats] = useState<Statistics | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchStatistics();
  }, []);

  const fetchStatistics = async () => {
    try {
      setLoading(true);
      const response = await api.get<Statistics>('/statistics/my-stats');
      setStats(response.data);
      setError(null);
    } catch (err) {
      setError('Erreur lors de la récupération des statistiques.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-purple-50 to-indigo-50 flex justify-center items-center">
        <div className="flex flex-col items-center">
          <div className="relative">
            <div className="absolute inset-0 bg-purple-400 rounded-full blur-2xl opacity-30 animate-pulse"></div>
            <Loader2 className="relative h-16 w-16 animate-spin text-purple-600 mb-4" />
          </div>
          <p className="text-lg text-gray-700 font-medium">Chargement des statistiques...</p>
        </div>
      </div>
    );
  }

  if (error || !stats) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-purple-50 to-indigo-50 flex items-center justify-center p-6">
        <div className="bg-red-50 border-2 border-red-200 rounded-3xl p-8 max-w-md">
          <p className="text-red-600 text-center font-semibold text-lg">{error || 'Impossible de charger les statistiques.'}</p>
        </div>
      </div>
    );
  }

  const taskCompletionRate = stats.totalTasks > 0 ? (stats.completedTasks / stats.totalTasks) * 100 : 0;
  const sprintCompletionRate = stats.totalSprints > 0 ? (stats.completedSprints / stats.totalSprints) * 100 : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-purple-50 to-indigo-50 p-6">
      {/* Background animated elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute w-96 h-96 bg-purple-300 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse" style={{ top: '-12rem', left: '-12rem' }}></div>
        <div className="absolute w-96 h-96 bg-blue-300 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse" style={{ bottom: '-12rem', right: '-12rem' }}></div>
      </div>

      <div className="relative max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center shadow-lg" style={{ boxShadow: '0 8px 25px rgba(168, 85, 247, 0.4)' }}>
              <BarChart2 className="h-6 w-6 text-white" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
              Statistiques Globales
            </h1>
          </div>
          <p className="text-gray-600 text-lg ml-15">Visualisez vos performances et progrès</p>
        </div>

        {/* Stats Grid - Cartes principales */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {/* Total Projets */}
          <div className="relative group">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-400 to-cyan-400 rounded-3xl opacity-0 group-hover:opacity-20 blur-xl transition-opacity duration-300"></div>
            <div className="relative bg-white p-6 rounded-3xl border-2 border-transparent hover:border-blue-200 transition-all duration-300" style={{ backgroundColor: 'rgba(255, 255, 255, 0.9)', backdropFilter: 'blur(16px)' }}>
              <div className="flex items-center justify-between mb-4">
                <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-2xl flex items-center justify-center shadow-lg" style={{ boxShadow: '0 8px 25px rgba(59, 130, 246, 0.4)' }}>
                  <Folder className="h-7 w-7 text-white" />
                </div>
                <div className="text-right">
                  <p className="text-5xl font-black bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent">
                    {stats.totalProjects}
                  </p>
                </div>
              </div>
              <p className="text-gray-700 font-semibold text-lg mb-1">Projets Totaux</p>
              <p className="text-gray-500 text-sm">Tous vos projets</p>
              <div className="mt-3 h-1 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full" style={{ width: '60%' }}></div>
            </div>
          </div>

          {/* Projets Actifs */}
          <div className="relative group">
            <div className="absolute inset-0 bg-gradient-to-r from-indigo-400 to-purple-400 rounded-3xl opacity-0 group-hover:opacity-20 blur-xl transition-opacity duration-300"></div>
            <div className="relative bg-white p-6 rounded-3xl border-2 border-transparent hover:border-indigo-200 transition-all duration-300" style={{ backgroundColor: 'rgba(255, 255, 255, 0.9)', backdropFilter: 'blur(16px)' }}>
              <div className="flex items-center justify-between mb-4">
                <div className="w-14 h-14 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-2xl flex items-center justify-center shadow-lg" style={{ boxShadow: '0 8px 25px rgba(99, 102, 241, 0.4)' }}>
                  <Activity className="h-7 w-7 text-white" />
                </div>
                <div className="text-right">
                  <p className="text-5xl font-black bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                    {stats.activeProjects}
                  </p>
                </div>
              </div>
              <p className="text-gray-700 font-semibold text-lg mb-1">Projets Actifs</p>
              <p className="text-gray-500 text-sm">En cours de réalisation</p>
              <div className="mt-3 h-1 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full" style={{ width: '75%' }}></div>
            </div>
          </div>

          {/* Projets Terminés */}
          <div className="relative group">
            <div className="absolute inset-0 bg-gradient-to-r from-green-400 to-emerald-400 rounded-3xl opacity-0 group-hover:opacity-20 blur-xl transition-opacity duration-300"></div>
            <div className="relative bg-white p-6 rounded-3xl border-2 border-transparent hover:border-green-200 transition-all duration-300" style={{ backgroundColor: 'rgba(255, 255, 255, 0.9)', backdropFilter: 'blur(16px)' }}>
              <div className="flex items-center justify-between mb-4">
                <div className="w-14 h-14 bg-gradient-to-br from-green-500 to-emerald-500 rounded-2xl flex items-center justify-center shadow-lg" style={{ boxShadow: '0 8px 25px rgba(34, 197, 94, 0.4)' }}>
                  <CheckCircle className="h-7 w-7 text-white" />
                </div>
                <div className="text-right">
                  <p className="text-5xl font-black bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
                    {stats.completedProjects}
                  </p>
                </div>
              </div>
              <p className="text-gray-700 font-semibold text-lg mb-1">Projets Terminés</p>
              <p className="text-gray-500 text-sm">Objectifs atteints ✨</p>
              <div className="mt-3 h-1 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full" style={{ width: '90%' }}></div>
            </div>
          </div>
        </div>

        {/* Section Sprints & Tâches */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Card Sprints avec graphique circulaire */}
          <div className="bg-white rounded-3xl p-8 border border-gray-100 shadow-xl" style={{ backgroundColor: 'rgba(255, 255, 255, 0.9)', backdropFilter: 'blur(16px)' }}>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center shadow-lg">
                <Flag className="h-6 w-6 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900">Sprints</h3>
            </div>

            <div className="flex items-center justify-between mb-6">
              <div className="flex-1">
                <div className="grid grid-cols-3 gap-4 mb-4">
                  <div>
                    <p className="text-gray-500 text-xs font-medium mb-1">Total</p>
                    <p className="text-2xl font-bold text-gray-900">{stats.totalSprints}</p>
                  </div>
                  <div>
                    <p className="text-gray-500 text-xs font-medium mb-1">Actifs</p>
                    <p className="text-2xl font-bold text-orange-600">{stats.activeSprints}</p>
                  </div>
                  <div>
                    <p className="text-gray-500 text-xs font-medium mb-1">Terminés</p>
                    <p className="text-2xl font-bold text-green-600">{stats.completedSprints}</p>
                  </div>
                </div>
              </div>

              {/* Graphique circulaire */}
              <div className="relative w-32 h-32">
                <svg className="transform -rotate-90 w-32 h-32">
                  <circle
                    cx="64"
                    cy="64"
                    r="56"
                    stroke="rgba(147, 51, 234, 0.1)"
                    strokeWidth="12"
                    fill="none"
                  />
                  <circle
                    cx="64"
                    cy="64"
                    r="56"
                    stroke="url(#gradient-sprint)"
                    strokeWidth="12"
                    fill="none"
                    strokeLinecap="round"
                    strokeDasharray={`${2 * Math.PI * 56}`}
                    strokeDashoffset={`${2 * Math.PI * 56 * (1 - sprintCompletionRate / 100)}`}
                    className="transition-all duration-500"
                  />
                  <defs>
                    <linearGradient id="gradient-sprint" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#a855f7" />
                      <stop offset="100%" stopColor="#ec4899" />
                    </linearGradient>
                  </defs>
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-2xl font-bold text-gray-900">{sprintCompletionRate.toFixed(0)}%</span>
                  <span className="text-xs text-gray-500 font-medium">Complétés</span>
                </div>
              </div>
            </div>

            <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-purple-500 to-pink-500 transition-all duration-700 rounded-full"
                style={{ width: `${sprintCompletionRate}%` }}
              ></div>
            </div>
          </div>

          {/* Card Tâches avec graphique circulaire */}
          <div className="bg-white rounded-3xl p-8 border border-gray-100 shadow-xl" style={{ backgroundColor: 'rgba(255, 255, 255, 0.9)', backdropFilter: 'blur(16px)' }}>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-rose-500 rounded-2xl flex items-center justify-center shadow-lg">
                <ListTodo className="h-6 w-6 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900">Tâches</h3>
            </div>

            <div className="flex items-center justify-between mb-6">
              <div className="flex-1">
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <p className="text-gray-500 text-xs font-medium mb-1">Total</p>
                    <p className="text-3xl font-bold text-gray-900">{stats.totalTasks}</p>
                  </div>
                  <div>
                    <p className="text-gray-500 text-xs font-medium mb-1">Terminées</p>
                    <p className="text-3xl font-bold text-green-600">{stats.completedTasks}</p>
                  </div>
                </div>
              </div>

              {/* Graphique circulaire */}
              <div className="relative w-32 h-32">
                <svg className="transform -rotate-90 w-32 h-32">
                  <circle
                    cx="64"
                    cy="64"
                    r="56"
                    stroke="rgba(239, 68, 68, 0.1)"
                    strokeWidth="12"
                    fill="none"
                  />
                  <circle
                    cx="64"
                    cy="64"
                    r="56"
                    stroke="url(#gradient-task)"
                    strokeWidth="12"
                    fill="none"
                    strokeLinecap="round"
                    strokeDasharray={`${2 * Math.PI * 56}`}
                    strokeDashoffset={`${2 * Math.PI * 56 * (1 - taskCompletionRate / 100)}`}
                    className="transition-all duration-500"
                  />
                  <defs>
                    <linearGradient id="gradient-task" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#ef4444" />
                      <stop offset="100%" stopColor="#f43f5e" />
                    </linearGradient>
                  </defs>
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-2xl font-bold text-gray-900">{taskCompletionRate.toFixed(0)}%</span>
                  <span className="text-xs text-gray-500 font-medium">Complétées</span>
                </div>
              </div>
            </div>

            <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-red-500 to-rose-500 transition-all duration-700 rounded-full"
                style={{ width: `${taskCompletionRate}%` }}
              ></div>
            </div>
          </div>
        </div>

        {/* Bottom Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Progression Moyenne */}
          <div className="relative group">
            <div className="absolute inset-0 bg-gradient-to-r from-teal-400 to-cyan-400 rounded-3xl opacity-0 group-hover:opacity-20 blur-xl transition-opacity duration-300"></div>
            <div className="relative bg-white p-8 rounded-3xl border-2 border-transparent hover:border-teal-200 transition-all duration-300" style={{ backgroundColor: 'rgba(255, 255, 255, 0.9)', backdropFilter: 'blur(16px)' }}>
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-teal-500 to-cyan-500 rounded-2xl flex items-center justify-center shadow-lg">
                    <TrendingUp className="h-8 w-8 text-white" />
                  </div>
                  <div>
                    <p className="text-gray-600 font-semibold mb-1">Progression Moyenne</p>
                    <p className="text-4xl font-black bg-gradient-to-r from-teal-600 to-cyan-600 bg-clip-text text-transparent">
                      {stats.averageProjectProgress.toFixed(1)}%
                    </p>
                  </div>
                </div>
              </div>
              <div className="h-4 bg-gray-100 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-teal-500 to-cyan-500 transition-all duration-700 rounded-full relative"
                  style={{ width: `${stats.averageProjectProgress}%` }}
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent opacity-30 animate-pulse"></div>
                </div>
              </div>
              <p className="text-gray-500 text-sm mt-3">Performance globale de vos projets</p>
            </div>
          </div>

          {/* Messages non lus */}
          <div className="relative group">
            <div className="absolute inset-0 bg-gradient-to-r from-pink-400 to-rose-400 rounded-3xl opacity-0 group-hover:opacity-20 blur-xl transition-opacity duration-300"></div>
            <div className="relative bg-white p-8 rounded-3xl border-2 border-transparent hover:border-pink-200 transition-all duration-300" style={{ backgroundColor: 'rgba(255, 255, 255, 0.9)', backdropFilter: 'blur(16px)' }}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-pink-500 to-rose-500 rounded-2xl flex items-center justify-center shadow-lg relative">
                    <MessageSquare className="h-8 w-8 text-white" />
                    {stats.unreadMessages > 0 && (
                      <div className="absolute -top-1 -right-1 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center">
                        <span className="text-white text-xs font-bold">{stats.unreadMessages > 9 ? '9+' : stats.unreadMessages}</span>
                      </div>
                    )}
                  </div>
                  <div>
                    <p className="text-gray-600 font-semibold mb-1">Messages Non Lus</p>
                    <p className="text-4xl font-black bg-gradient-to-r from-pink-600 to-rose-600 bg-clip-text text-transparent">
                      {stats.unreadMessages}
                    </p>
                  </div>
                </div>
                {stats.unreadMessages > 0 && (
                  <Sparkles className="h-8 w-8 text-pink-400 animate-pulse" />
                )}
              </div>
              <p className="text-gray-500 text-sm mt-6">
                {stats.unreadMessages === 0 ? 'Aucun message en attente 🎉' : 'Nouveaux messages à consulter'}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StatsPage;