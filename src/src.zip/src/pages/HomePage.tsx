import React from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle, Users, Zap, TrendingUp } from 'lucide-react';

const HomePage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute w-96 h-96 bg-purple-300 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-pulse" style={{ top: '-12rem', left: '-12rem' }}></div>
        <div className="absolute w-96 h-96 bg-blue-300 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-pulse" style={{ bottom: '-12rem', right: '-12rem', animationDelay: '1000ms' }}></div>
        <div className="absolute w-96 h-96 bg-pink-300 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse" style={{ top: '50%', left: '50%', transform: 'translate(-50%, -50%)', animationDelay: '500ms' }}></div>
      </div>

      <div className="relative flex flex-col items-center justify-center min-h-screen p-4">
        {/* Hero Section */}
        <div className="max-w-5xl w-full text-center mb-12">
          <div className="inline-block mb-4 px-4 py-2 bg-white rounded-full border border-purple-200 shadow-sm" style={{ backgroundColor: 'rgba(255, 255, 255, 0.8)', backdropFilter: 'blur(8px)' }}>
            <span className="text-purple-600 text-sm font-medium">✨ Plateforme de gestion collaborative</span>
          </div>
          
          <h1 className="text-6xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 bg-clip-text text-transparent leading-tight">
            Gestion Projets
          </h1>
          
          <p className="text-xl md:text-2xl text-gray-700 mb-8 max-w-2xl mx-auto leading-relaxed">
            Transformez vos idées en réalité. Organisez, collaborez et dépassez vos objectifs avec une plateforme pensée pour la réussite.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row justify-center gap-4 mb-16">
            <Link to="/login" className="group">
              <button className="w-full sm:w-auto bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-semibold py-4 px-10 rounded-2xl shadow-xl transform hover:scale-105 transition-all duration-300 ease-out relative overflow-hidden" style={{ boxShadow: '0 10px 40px rgba(139, 92, 246, 0.3)' }}>
                <span className="relative z-10">Se connecter</span>
                <div className="absolute inset-0 bg-gradient-to-r from-indigo-700 to-purple-700 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </button>
            </Link>
            
            <Link to="/register" className="group">
              <button className="w-full sm:w-auto bg-white text-gray-800 font-semibold py-4 px-10 rounded-2xl border-2 border-gray-200 hover:border-purple-300 hover:bg-purple-50 transform hover:scale-105 transition-all duration-300 ease-out shadow-lg hover:shadow-xl">
                S'inscrire gratuitement
              </button>
            </Link>
          </div>
        </div>

        {/* Features Grid */}
        <div className="max-w-6xl w-full grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          <div className="bg-white p-6 rounded-3xl border border-gray-100 hover:bg-white hover:shadow-xl hover:border-purple-200 transition-all duration-300 group" style={{ backgroundColor: 'rgba(255, 255, 255, 0.7)', backdropFilter: 'blur(16px)' }}>
            <div className="w-14 h-14 bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300 shadow-lg" style={{ boxShadow: '0 4px 20px rgba(168, 85, 247, 0.3)' }}>
              <CheckCircle className="w-7 h-7 text-white" />
            </div>
            <h3 className="text-gray-900 font-semibold text-lg mb-2">Organisation fluide</h3>
            <p className="text-gray-600 text-sm">Structurez vos projets avec des outils intuitifs et performants</p>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-gray-100 hover:bg-white hover:shadow-xl hover:border-blue-200 transition-all duration-300 group" style={{ backgroundColor: 'rgba(255, 255, 255, 0.7)', backdropFilter: 'blur(16px)' }}>
            <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300 shadow-lg" style={{ boxShadow: '0 4px 20px rgba(59, 130, 246, 0.3)' }}>
              <Users className="w-7 h-7 text-white" />
            </div>
            <h3 className="text-gray-900 font-semibold text-lg mb-2">Collaboration en temps réel</h3>
            <p className="text-gray-600 text-sm">Travaillez ensemble, où que vous soyez, en toute simplicité</p>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-gray-100 hover:bg-white hover:shadow-xl hover:border-pink-200 transition-all duration-300 group" style={{ backgroundColor: 'rgba(255, 255, 255, 0.7)', backdropFilter: 'blur(16px)' }}>
            <div className="w-14 h-14 bg-gradient-to-br from-pink-500 to-rose-500 rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300 shadow-lg" style={{ boxShadow: '0 4px 20px rgba(236, 72, 153, 0.3)' }}>
              <Zap className="w-7 h-7 text-white" />
            </div>
            <h3 className="text-gray-900 font-semibold text-lg mb-2">Rapidité d'exécution</h3>
            <p className="text-gray-600 text-sm">Gagnez du temps avec des workflows optimisés et automatisés</p>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-gray-100 hover:bg-white hover:shadow-xl hover:border-indigo-200 transition-all duration-300 group" style={{ backgroundColor: 'rgba(255, 255, 255, 0.7)', backdropFilter: 'blur(16px)' }}>
            <div className="w-14 h-14 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300 shadow-lg" style={{ boxShadow: '0 4px 20px rgba(99, 102, 241, 0.3)' }}>
              <TrendingUp className="w-7 h-7 text-white" />
            </div>
            <h3 className="text-gray-900 font-semibold text-lg mb-2">Suivi de performance</h3>
            <p className="text-gray-600 text-sm">Mesurez vos progrès et atteignez vos objectifs plus rapidement</p>
          </div>
        </div>

        {/* Bottom CTA */}
        <div className="text-center">
          <p className="text-gray-600 text-sm">
            🚀 Rejoignez des milliers d'équipes qui réussissent leurs projets
          </p>
        </div>
      </div>
    </div>
  );
};

export default HomePage;