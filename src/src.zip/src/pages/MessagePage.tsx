import React, { useEffect, useState, useRef, useCallback } from 'react';
import { useParams } from 'react-router-dom';
import api from '../services/api';
import { Loader2, Send, CheckCheck } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useSse } from '../context/SseContext';

interface Message {
  id: number;
  senderId: number;
  senderFirstname: string;
  senderLastname: string;
  senderEmail: string;
  content: string;
  sentAt: string;
  projectId: number;
  isRead: boolean;
}

// Helper pour formater la date
const formatDate = (dateString: string) => {
  const date = new Date(dateString);
  const today = new Date();
  const yesterday = new Date(today);
  yesterday.setDate(today.getDate() - 1);

  if (date.toDateString() === today.toDateString()) return "Aujourd'hui";
  if (date.toDateString() === yesterday.toDateString()) return "Hier";
  return date.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });
};

const MessagePage: React.FC = () => {
  const { projectId } = useParams<{ projectId: string }>();
  const { user } = useAuth();
  const { lastMessage, messageReadUpdate, typingStatus, presenceStatus } = useSse();

  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [newMessageContent, setNewMessageContent] = useState('');
  const [projectMembers, setProjectMembers] = useState<any[]>([]);

  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const pId = Number(projectId);

  const usersTypingInProject = typingStatus
    ? typingStatus.filter(ts => ts.projectId === pId && ts.senderId !== user?.id)
    : [];

  const getChatHeaderStatus = useCallback(() => {
    if (usersTypingInProject.length > 0) {
      const typingNames = usersTypingInProject.map(ts => ts.senderName).join(', ');
      return `${typingNames} est en train d'écrire...`;
    }

    const otherMembers = projectMembers.filter(member => member.id !== user?.id);

    if (otherMembers.length === 1) {
      const otherMember = otherMembers[0];
      const status = presenceStatus?.get(otherMember.id);
      if (status?.isOnline) return "En ligne";
      if (status?.lastSeen) {
        const date = new Date(status.lastSeen);
        return `Vu pour la dernière fois le ${date.toLocaleDateString()} à ${date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
      }
      return "";
    } else if (otherMembers.length > 1) {
      const onlineMembers = otherMembers.filter(member => presenceStatus?.get(member.id)?.isOnline);
      return onlineMembers.length > 0 ? `${onlineMembers.length} en ligne` : `${otherMembers.length} membres`;
    }
    return "";
  }, [projectMembers, user, presenceStatus, usersTypingInProject]);

  useEffect(() => {
    if (!pId) return;

    setLoading(true);
    api.get<Message[]>(`/messages/project/${pId}`)
      .then(response => {
        setMessages(Array.isArray(response.data) ? response.data : []);
        if (document.hasFocus()) {
          api.put(`/messages/project/${pId}/mark-as-read`).catch(console.error);
        }
      })
      .catch(() => setError('Erreur lors de la récupération de l\'historique.'))
      .finally(() => setLoading(false));
  }, [pId]);

  useEffect(() => {
    if (!pId) return;
    api.get(`/projects/${pId}`).then(response => {
      setProjectMembers(Array.isArray(response.data.members) ? response.data.members.map((m: any) => m.user) : []);
    }).catch(console.error);
  }, [pId]);

  useEffect(() => {
    if (lastMessage && lastMessage.projectId === pId) {
      const exists = messages.some(msg => msg.id === lastMessage.id);
      if (!exists) setMessages(prev => [...prev, lastMessage as Message]);
    }
  }, [lastMessage, pId, messages]);

  useEffect(() => {
    if (messageReadUpdate && messageReadUpdate.projectId === pId) {
      setMessages(prev => prev.map(msg => ({ ...msg, isRead: true })));
    }
  }, [messageReadUpdate, pId]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleTyping = useCallback(() => {
    if (!user || !pId) return;

    api.post(`/typing/project/${pId}/start`).catch(console.error);

    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);

    typingTimeoutRef.current = setTimeout(() => {
      api.post(`/typing/project/${pId}/stop`).catch(console.error);
      typingTimeoutRef.current = null;
    }, 3000);
  }, [user, pId]);

  const handleSendMessage = async () => {
    if (!newMessageContent.trim() || !projectId) return;

    const chatMessage = { projectId: pId, content: newMessageContent };
    try {
      setNewMessageContent('');
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
        api.post(`/typing/project/${pId}/stop`).catch(console.error);
        typingTimeoutRef.current = null;
      }
      await api.post('/messages', chatMessage);
    } catch (err) {
      setError("Erreur lors de l'envoi du message.");
      setNewMessageContent(chatMessage.content);
    }
  };

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = textareaRef.current.scrollHeight + 'px';
    }
  }, [newMessageContent]);

  if (loading) return <div className="flex justify-center items-center h-full"><Loader2 className="h-8 w-8 animate-spin text-indigo-600" /></div>;
  if (error) return <div className="text-center p-8 text-red-600">{error}</div>;

  let lastDate = '';

  return (
    <div className="flex flex-col h-full bg-gradient-to-br from-slate-50 via-purple-50 to-indigo-50">
      {/* HEADER */}
      <div className="p-4 border-b border-gray-200 flex items-center justify-between bg-white shadow-sm">
        <div>
          <h2 className="text-xl font-bold text-gray-800">
            {messages.length > 0 ? messages[0].projectName : `Projet ${projectId}`}
          </h2>
          <p className="text-sm text-gray-500">{getChatHeaderStatus()}</p>
        </div>
      </div>

      {/* MESSAGES */}
      <div className="flex-1 p-6 overflow-y-auto space-y-4">
        {messages.map((msg, index) => {
          const isMine = msg.senderEmail === user?.email;
          const senderName = isMine ? 'Vous' : `${msg.senderFirstname} ${msg.senderLastname}`;
          const msgDate = formatDate(msg.sentAt);
          const showDateHeader = msgDate !== lastDate;
          lastDate = msgDate;

          return (
            <React.Fragment key={msg.id || `msg-${index}`}>
              {showDateHeader && (
                <div className="flex justify-center my-2">
                  <span className="bg-gray-200 text-gray-600 text-xs px-3 py-1 rounded-full">{msgDate}</span>
                </div>
              )}
              <div className={`flex ${isMine ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[70%] p-3 rounded-xl shadow-md ${isMine ? 'bg-indigo-500 text-white rounded-br-none' : 'bg-white text-gray-800 rounded-bl-none'}`}>
                  <div className="font-semibold text-sm mb-1">{senderName}</div>
                  <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                  <div className="flex items-center justify-end text-xs mt-1 opacity-80">
                    <span>{new Date(msg.sentAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    {isMine && msg.isRead && <CheckCheck size={14} className="ml-1 text-blue-400" />}
                  </div>
                </div>
              </div>
            </React.Fragment>
          );
        })}
        <div ref={messagesEndRef} />
      </div>

      {usersTypingInProject.length > 0 && (
        <div className="p-2 text-sm text-gray-600 text-center">
          {usersTypingInProject.map(ts => ts.senderName).join(', ')} est en train d'écrire...
        </div>
      )}

      {/* INPUT */}
      <div className="p-4 border-t border-gray-200 flex items-center bg-white shadow-inner">
        <textarea
          ref={textareaRef}
          value={newMessageContent}
          onChange={e => { setNewMessageContent(e.target.value); handleTyping(); }}
          onKeyPress={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSendMessage(); } }}
          placeholder="Écrivez votre message..."
          className="flex-1 border border-gray-300 p-3 rounded-lg focus:ring-indigo-500 focus:border-indigo-500 resize-none mr-4"
          rows={1}
        />
        <button onClick={handleSendMessage} className="flex items-center bg-indigo-600 text-white font-semibold py-3 px-5 rounded-lg shadow-md hover:bg-indigo-700 transition duration-300">
          <Send className="mr-2 h-5 w-5" /> Envoyer
        </button>
      </div>
    </div>
  );
};

export default MessagePage;
