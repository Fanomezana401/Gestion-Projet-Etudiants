import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  PlusCircle,
  Eye,
  Loader2,
  Trash2,
  FolderOpen,
  Sparkles,
  ArrowRight,
  Calendar,
  Users
} from 'lucide-react';
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip
} from 'recharts';
import api from '../services/api';

/* ===================== TYPES ===================== */
interface Project {
  id: number;
  name: string;
  description: string;
  progress: number;
  status: string;
}

/* ===================== HELPERS ===================== */
const getStatusConfig = (status?: string) => {
  switch (status) {
    case 'En cours':
      return { bg: 'from-blue-500 to-cyan-500', icon: '🚀', text: 'En cours' };
    case 'Terminé':
      return { bg: 'from-green-500 to-emerald-500', icon: '✅', text: 'Terminé' };
    case 'Nouveau':
      return { bg: 'from-purple-500 to-pink-500', icon: '✨', text: 'Nouveau' };
    default:
      return {
        bg: 'from-amber-500 to-orange-500',
        icon: '⚡',
        text: status || 'En attente'
      };
  }
};

const getStats = (projects: Project[]) => {
  const total = projects.length;
  const completed = projects.filter(p => p.progress === 100).length;
  const avgProgress =
    total === 0
      ? 0
      : Math.round(projects.reduce((acc, p) => acc + p.progress, 0) / total);

  const byStatus = projects.reduce<Record<string, number>>((acc, p) => {
    acc[p.status || 'En attente'] = (acc[p.status || 'En attente'] || 0) + 1;
    return acc;
  }, {});

  return { total, completed, avgProgress, byStatus };
};

const COLORS = ['#6366f1', '#22c55e', '#ec4899', '#f59e0b'];

/* ===================== PAGE ===================== */
const ProjectListPage: React.FC = () => {
  const navigate = useNavigate();
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchProjects();
  }, []);

  const fetchProjects = async () => {
    try {
      setLoading(true);
      const { data } = await api.get('/projects/my-projects');
      setProjects(data);
      setError(null);
    } catch (err) {
      setError('Erreur lors de la récupération des projets.');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteProject = async (id: number, name: string) => {
    if (!window.confirm(`Supprimer le projet "${name}" ?`)) return;
    await api.delete(`/projects/${id}`);
    fetchProjects();
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 via-purple-50 to-indigo-50">
        <Loader2 className="h-16 w-16 animate-spin text-purple-600" />
      </div>
    );
  }

  const stats = getStats(projects);
  const chartData = Object.entries(stats.byStatus).map(([name, value]) => ({
    name,
    value
  }));

  return (
    <div className="min-h-screen p-6 bg-gradient-to-br from-slate-50 via-purple-50 to-indigo-50">
      <div className="max-w-7xl mx-auto">

        {/* HEADER */}
        <div className="flex justify-between items-center mb-10">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
              <FolderOpen className="text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">Mes projets</h1>
              <p className="text-gray-500">Vue globale & suivi</p>
            </div>
          </div>

          <Link to="/projects/new">
            <button className="flex items-center gap-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-6 py-3 rounded-2xl font-semibold shadow-lg hover:scale-105">
              <PlusCircle /> Nouveau projet
            </button>
          </Link>
        </div>

        {/* DASHBOARD */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
          <div className="bg-white rounded-3xl p-6 shadow-xl">
            <p className="text-sm text-gray-400">Total projets</p>
            <p className="text-4xl font-bold">{stats.total}</p>
          </div>

          <div className="bg-white rounded-3xl p-6 shadow-xl">
            <p className="text-sm text-gray-400">Terminés</p>
            <p className="text-4xl font-bold text-green-600">
              {stats.completed}
            </p>
          </div>

          <div className="bg-white rounded-3xl p-6 shadow-xl">
            <p className="text-sm text-gray-400 mb-2">Progression moyenne</p>
            <p className="text-4xl font-bold text-indigo-600 mb-2">
              {stats.avgProgress}%
            </p>
            <div className="h-2 bg-gray-200 rounded-full">
              <div
                className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full"
                style={{ width: `${stats.avgProgress}%` }}
              />
            </div>
          </div>
        </div>

        {/* GRAPH */}
        <div className="bg-white rounded-3xl p-6 shadow-xl mb-12">
          <h3 className="font-bold mb-4">Répartition des statuts</h3>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={chartData}
                  innerRadius={60}
                  outerRadius={100}
                  dataKey="value"
                  paddingAngle={6}
                >
                  {chartData.map((_, i) => (
                    <Cell key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* LISTE PROJETS */}
        <div className="space-y-6">
          {projects.map(project => {
            const status = getStatusConfig(project.status);
            return (
              <div
                key={project.id}
                className="bg-white rounded-3xl p-6 shadow-xl border hover:shadow-2xl transition"
              >
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="text-xl font-bold">{project.name}</h3>
                    <p className="text-sm text-gray-500 line-clamp-2">
                      {project.description}
                    </p>
                    <span className={`mt-2 inline-flex px-3 py-1 rounded-full text-xs font-bold text-white bg-gradient-to-r ${status.bg}`}>
                      {status.icon} {status.text}
                    </span>
                  </div>

                  <div className="flex gap-3">
                    <Link to={`/projects/${project.id}`}>
                      <button className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-xl hover:scale-105">
                        <Eye size={18} /> Voir
                      </button>
                    </Link>
                    <button
                      onClick={() =>
                        handleDeleteProject(project.id, project.name)
                      }
                      className="bg-red-600 text-white p-2 rounded-xl hover:scale-105"
                    >
                      <Trash2 />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </div>
  );
};

export default ProjectListPage;
