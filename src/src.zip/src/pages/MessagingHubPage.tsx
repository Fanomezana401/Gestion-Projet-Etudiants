import React, { useEffect, useState, useCallback } from 'react';
import { NavLink, Outlet, useLocation } from 'react-router-dom';
import api from '../services/api';
import { Loader2, MessageSquare } from 'lucide-react';
import { useSse } from '../context/SseContext';

interface Project {
  id: number;
  name: string;
}

const MessagingHubPage: React.FC = () => {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const location = useLocation();
  const { projectUnreadCounts } = useSse();

  const fetchProjects = useCallback(async () => {
    try {
      const response = await api.get<Project[]>('/projects/my-projects');
      setProjects(response.data);
      setError(null);
    } catch (err) {
      setError('Erreur lors de la récupération des projets.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchProjects();
  }, [fetchProjects]);

  if (loading) return <div className="flex justify-center items-center h-full"><Loader2 className="h-8 w-8 animate-spin text-indigo-600" /></div>;
  if (error) return <div className="text-center p-8 text-red-600">{error}</div>;

  const isConversationActive = location.pathname.startsWith('/messages/');

  return (
    <div className="flex h-full bg-gradient-to-br from-slate-50 via-purple-50 to-indigo-50 rounded-lg shadow-lg overflow-hidden">
      {/* SIDEBAR */}
      <aside className={`w-1/3 border-r border-gray-200 flex flex-col ${isConversationActive ? 'hidden md:flex' : 'flex'}`}>
        <div className="p-4 border-b border-gray-200 bg-white shadow-sm">
          <h2 className="text-xl font-bold text-gray-800">Conversations</h2>
        </div>
        <div className="flex-1 overflow-y-auto">
          {projects.length === 0 ? (
            <div className="p-6 text-center text-gray-500">
              <p>Vous n'êtes membre d'aucun projet.</p>
            </div>
          ) : (
            projects.map(project => {
              const unreadCount = projectUnreadCounts.get(project.id) || 0;
              return (
                <NavLink
                  key={project.id}
                  to={`/messages/${project.id}`}
                  className={({ isActive }) =>
                    `flex items-center justify-between p-4 border-b border-gray-200 hover:bg-gray-50 ${isActive ? 'bg-indigo-50' : ''}`
                  }
                >
                  <div className="flex items-center">
                    <div className="w-10 h-10 bg-indigo-500 rounded-full flex items-center justify-center text-white font-bold mr-3">
                      {project.name.charAt(0)}
                    </div>
                    <span className="font-semibold text-gray-700">{project.name}</span>
                  </div>
                  {unreadCount > 0 && (
                    <span className="bg-red-500 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                      {unreadCount}
                    </span>
                  )}
                </NavLink>
              );
            })
          )}
        </div>
      </aside>

      {/* MAIN */}
      <main className="flex-1 flex flex-col">
        {isConversationActive ? (
          <Outlet />
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-gray-500">
            <MessageSquare size={48} />
            <p className="mt-4 text-lg">Sélectionnez une conversation pour commencer</p>
          </div>
        )}
      </main>
    </div>
  );
};

export default MessagingHubPage;
