import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { PlusCircle, Book, BarChart2, Bell, Loader2, Eye, Sparkles, ArrowRight, Calendar, Users as UsersIcon } from 'lucide-react';
import api from '../services/api';

interface Project {
  id: number;
  name: string;
  description: string;
  progress: number;
  status: string;
}

const getStatusConfig = (status?: string) => {
  switch (status) {
    case 'En cours':
      return { 
        bg: 'from-blue-500 to-cyan-500',
        icon: '🚀',
        text: 'En cours'
      };
    case 'Terminé':
      return { 
        bg: 'from-green-500 to-emerald-500',
        icon: '✅',
        text: 'Terminé'
      };
    case 'Nouveau':
      return { 
        bg: 'from-purple-500 to-pink-500',
        icon: '✨',
        text: 'Nouveau'
      };
    default:
      return { 
        bg: 'from-amber-500 to-orange-500',
        icon: '⚡',
        text: status || 'En attente'
      };
  }
};

const DashboardPage: React.FC = () => {
  const { user } = useAuth();
  const [projects, setProjects] = useState<Project[]>([]);
  const [completedTasksCount, setCompletedTasksCount] = useState<number>(0);
  const [unreadMessagesCount, setUnreadMessagesCount] = useState<number>(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const [projectsResponse, tasksCountResponse, messagesCountResponse] = await Promise.all([
          api.get('/projects/my-projects'),
          api.get('/tasks/count/completed'),
          api.get('/messages/count/unread')
        ]);

        setProjects(projectsResponse.data);
        setCompletedTasksCount(tasksCountResponse.data.count);
        setUnreadMessagesCount(messagesCountResponse.data.count);
        setError(null);
      } catch (err) {
        setError('Erreur lors de la récupération des données du tableau de bord.');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-purple-50 to-indigo-50 p-6">
      {/* Background animated elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute w-96 h-96 bg-purple-300 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse" style={{ top: '-12rem', left: '-12rem' }}></div>
        <div className="absolute w-96 h-96 bg-blue-300 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse" style={{ bottom: '-12rem', right: '-12rem' }}></div>
      </div>

      <div className="relative max-w-7xl mx-auto">
        {/* Header Section */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="h-6 w-6 text-purple-500" />
              <h1 className="text-4xl font-bold bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
                Bonjour, {user?.firstname || 'Étudiant'} !
              </h1>
            </div>
            <p className="text-gray-600 text-lg">Bienvenue sur votre tableau de bord.</p>
          </div>
          <Link to="/projects/new">
            <button className="group flex items-center bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-semibold py-3 px-6 rounded-2xl shadow-xl transform hover:scale-105 transition-all duration-300 relative overflow-hidden" style={{ boxShadow: '0 10px 40px rgba(139, 92, 246, 0.3)' }}>
              <span className="relative z-10 flex items-center">
                <PlusCircle className="mr-2 h-5 w-5" />
                Créer un projet
              </span>
              <div className="absolute inset-0 bg-gradient-to-r from-indigo-700 to-purple-700 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </button>
          </Link>
        </div>

        {/* Stats Cards - Version améliorée */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="relative group">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-400 to-cyan-400 rounded-3xl opacity-0 group-hover:opacity-20 blur-xl transition-opacity duration-300"></div>
            <div className="relative bg-white p-6 rounded-3xl border-2 border-transparent hover:border-blue-200 transition-all duration-300" style={{ backgroundColor: 'rgba(255, 255, 255, 0.9)', backdropFilter: 'blur(16px)' }}>
              <div className="flex items-center justify-between mb-3">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-2xl flex items-center justify-center shadow-lg" style={{ boxShadow: '0 8px 25px rgba(59, 130, 246, 0.4)' }}>
                  <Book className="h-6 w-6 text-white" />
                </div>
                <div className="text-right">
                  <p className="text-4xl font-black bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent">
                    {loading ? '...' : projects.filter(p => p.status !== 'Terminé').length}
                  </p>
                </div>
              </div>
              <p className="text-gray-600 text-sm font-semibold">Projets Actifs</p>
              <div className="mt-2 h-1 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full" style={{ width: '40%' }}></div>
            </div>
          </div>

          <div className="relative group">
            <div className="absolute inset-0 bg-gradient-to-r from-green-400 to-emerald-400 rounded-3xl opacity-0 group-hover:opacity-20 blur-xl transition-opacity duration-300"></div>
            <div className="relative bg-white p-6 rounded-3xl border-2 border-transparent hover:border-green-200 transition-all duration-300" style={{ backgroundColor: 'rgba(255, 255, 255, 0.9)', backdropFilter: 'blur(16px)' }}>
              <div className="flex items-center justify-between mb-3">
                <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-500 rounded-2xl flex items-center justify-center shadow-lg" style={{ boxShadow: '0 8px 25px rgba(34, 197, 94, 0.4)' }}>
                  <BarChart2 className="h-6 w-6 text-white" />
                </div>
                <div className="text-right">
                  <p className="text-4xl font-black bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
                    {loading ? '...' : completedTasksCount}
                  </p>
                </div>
              </div>
              <p className="text-gray-600 text-sm font-semibold">Tâches Terminées</p>
              <div className="mt-2 h-1 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full" style={{ width: '65%' }}></div>
            </div>
          </div>

          <div className="relative group">
            <div className="absolute inset-0 bg-gradient-to-r from-pink-400 to-rose-400 rounded-3xl opacity-0 group-hover:opacity-20 blur-xl transition-opacity duration-300"></div>
            <div className="relative bg-white p-6 rounded-3xl border-2 border-transparent hover:border-pink-200 transition-all duration-300" style={{ backgroundColor: 'rgba(255, 255, 255, 0.9)', backdropFilter: 'blur(16px)' }}>
              <div className="flex items-center justify-between mb-3">
                <div className="w-12 h-12 bg-gradient-to-br from-pink-500 to-rose-500 rounded-2xl flex items-center justify-center shadow-lg" style={{ boxShadow: '0 8px 25px rgba(236, 72, 153, 0.4)' }}>
                  <Bell className="h-6 w-6 text-white" />
                </div>
                <div className="text-right">
                  <p className="text-4xl font-black bg-gradient-to-r from-pink-600 to-rose-600 bg-clip-text text-transparent">
                    {loading ? '...' : unreadMessagesCount}
                  </p>
                </div>
              </div>
              <p className="text-gray-600 text-sm font-semibold">Notifications</p>
              <div className="mt-2 h-1 bg-gradient-to-r from-pink-500 to-rose-500 rounded-full" style={{ width: '50%' }}></div>
              {!loading && unreadMessagesCount > 0 && (
                <div className="absolute top-3 right-3 w-3 h-3 bg-pink-500 rounded-full animate-pulse shadow-lg" style={{ boxShadow: '0 0 15px rgba(236, 72, 153, 0.7)' }}></div>
              )}
            </div>
          </div>
        </div>

        {/* Projects Section - Design révolutionnaire */}
        <div className="bg-white rounded-3xl p-8 border border-gray-100" style={{ backgroundColor: 'rgba(255, 255, 255, 0.9)', backdropFilter: 'blur(16px)' }}>
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-3xl font-bold bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 bg-clip-text text-transparent mb-1">
                Mes Projets
              </h2>
              <p className="text-gray-500 text-sm">Gérez et suivez vos projets en temps réel</p>
            </div>
          </div>

          {loading && (
            <div className="flex flex-col justify-center items-center p-12">
              <Loader2 className="h-12 w-12 animate-spin text-purple-600 mb-4" />
              <p className="text-gray-600 text-lg">Chargement des projets...</p>
            </div>
          )}

          {error && (
            <div className="bg-red-50 border-2 border-red-200 rounded-2xl p-4">
              <p className="text-red-600 text-center">{error}</p>
            </div>
          )}

          {!loading && !error && (
            <div className="space-y-5">
              {projects.length === 0 ? (
                <div className="text-center py-16">
                  <div className="w-24 h-24 bg-gradient-to-br from-purple-100 to-pink-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Book className="h-12 w-12 text-purple-400" />
                  </div>
                  <p className="text-gray-700 text-xl font-semibold mb-2">Aucun projet pour le moment</p>
                  <p className="text-gray-500">Créez votre premier projet pour commencer !</p>
                </div>
              ) : (
                projects.map((project) => {
                  const statusConfig = getStatusConfig(project.status);
                  return (
                    <div 
                      key={project.id} 
                      className="group relative overflow-hidden rounded-3xl transition-all duration-300 hover:shadow-2xl"
                      style={{ 
                        background: 'linear-gradient(135deg, rgba(255, 255, 255, 0.95) 0%, rgba(249, 245, 255, 0.95) 100%)',
                        border: '2px solid rgba(147, 51, 234, 0.1)'
                      }}
                    >
                      {/* Gradient Accent Bar */}
                      <div 
                        className={`absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r ${statusConfig.bg}`}
                      ></div>

                      <div className="p-6">
                        {/* Header avec nom et statut */}
                        <div className="flex items-start justify-between mb-4">
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                              <h3 className="text-2xl font-bold text-gray-900 group-hover:text-purple-600 transition-colors">
                                {project.name}
                              </h3>
                              <span 
                                className={`flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-full bg-gradient-to-r ${statusConfig.bg} text-white shadow-md`}
                              >
                                <span>{statusConfig.icon}</span>
                                <span>{statusConfig.text}</span>
                              </span>
                            </div>
                            {project.description && (
                              <p className="text-gray-600 text-sm leading-relaxed line-clamp-2">
                                {project.description}
                              </p>
                            )}
                          </div>
                        </div>

                        {/* Barre de progression circulaire + linéaire hybride */}
                        <div className="mb-5">
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center gap-2">
                              <div className="relative w-12 h-12">
                                {/* Cercle de fond */}
                                <svg className="transform -rotate-90 w-12 h-12">
                                  <circle
                                    cx="24"
                                    cy="24"
                                    r="20"
                                    stroke="rgba(147, 51, 234, 0.1)"
                                    strokeWidth="4"
                                    fill="none"
                                  />
                                  <circle
                                    cx="24"
                                    cy="24"
                                    r="20"
                                    stroke="url(#gradient)"
                                    strokeWidth="4"
                                    fill="none"
                                    strokeLinecap="round"
                                    strokeDasharray={`${2 * Math.PI * 20}`}
                                    strokeDashoffset={`${2 * Math.PI * 20 * (1 - project.progress / 100)}`}
                                    className="transition-all duration-500"
                                  />
                                  <defs>
                                    <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                                      <stop offset="0%" stopColor="#6366f1" />
                                      <stop offset="50%" stopColor="#a855f7" />
                                      <stop offset="100%" stopColor="#ec4899" />
                                    </linearGradient>
                                  </defs>
                                </svg>
                                <div className="absolute inset-0 flex items-center justify-center">
                                  <span className="text-xs font-bold text-gray-700">{project.progress}%</span>
                                </div>
                              </div>
                              <div className="text-sm">
                                <p className="font-semibold text-gray-700">Progression</p>
                                <p className="text-xs text-gray-500">
                                  {project.progress === 100 ? 'Terminé' : project.progress >= 75 ? 'Presque fini' : project.progress >= 50 ? 'En bonne voie' : 'En démarrage'}
                                </p>
                              </div>
                            </div>
                            
                            <Link to={`/projects/${project.id}`}>
                              <button className="flex items-center gap-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-semibold py-2.5 px-5 rounded-xl shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-300 group/btn" style={{ boxShadow: '0 4px 20px rgba(99, 102, 241, 0.4)' }}>
                                <Eye className="h-4 w-4" />
                                <span>Voir</span>
                                <ArrowRight className="h-4 w-4 group-hover/btn:translate-x-1 transition-transform" />
                              </button>
                            </Link>
                          </div>

                          {/* Barre de progression moderne avec segments */}
                          <div className="relative h-3 bg-gray-100 rounded-full overflow-hidden">
                            <div 
                              className="absolute inset-y-0 left-0 rounded-full transition-all duration-700 ease-out"
                              style={{ 
                                width: `${project.progress}%`,
                                background: 'linear-gradient(90deg, #6366f1 0%, #a855f7 50%, #ec4899 100%)',
                                boxShadow: '0 2px 10px rgba(147, 51, 234, 0.4)'
                              }}
                            >
                              {/* Effet de brillance animé */}
                              <div 
                                className="absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent opacity-30"
                                style={{ 
                                  animation: 'shimmer 2s infinite',
                                  backgroundSize: '200% 100%'
                                }}
                              ></div>
                            </div>
                            
                            {/* Points de repère */}
                            <div className="absolute inset-0 flex items-center justify-between px-1">
                              {[25, 50, 75].map((mark) => (
                                <div 
                                  key={mark} 
                                  className="w-0.5 h-2 bg-white rounded-full opacity-50"
                                  style={{ marginLeft: `${mark}%` }}
                                ></div>
                              ))}
                            </div>
                          </div>
                        </div>

                        {/* Métadonnées du projet */}
                        <div className="flex items-center gap-6 text-xs text-gray-500">
                          <div className="flex items-center gap-1.5">
                            <Calendar className="h-3.5 w-3.5" />
                            <span>Créé récemment</span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <UsersIcon className="h-3.5 w-3.5" />
                            <span>Équipe collaborative</span>
                          </div>
                        </div>
                      </div>

                      {/* Effet de hover sur toute la carte */}
                      <div className="absolute inset-0 bg-gradient-to-r from-purple-500/0 via-pink-500/0 to-blue-500/0 group-hover:from-purple-500/5 group-hover:via-pink-500/5 group-hover:to-blue-500/5 transition-all duration-300 pointer-events-none rounded-3xl"></div>
                    </div>
                  );
                })
              )}
            </div>
          )}
        </div>
      </div>

      {/* Animation CSS pour l'effet shimmer */}
      <style>{`
        @keyframes shimmer {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
      `}</style>
    </div>
  );
};

export default DashboardPage;