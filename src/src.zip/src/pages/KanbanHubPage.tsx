import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Loader2, KanbanSquare, Calendar, CheckCircle, Clock, Sparkles, ArrowRight, Layers } from 'lucide-react';
import api from '../services/api';

// Interfaces pour correspondre aux DTOs du backend
interface Sprint {
  id: number;
  name: string;
  sprintNumber: number;
  startDate: string;
  endDate: string;
  status: string;
}

interface Project {
  id: number;
  name: string;
  description: string;
  progress: number;
  status: string;
  sprints: Sprint[];
}

const getSprintStatusConfig = (status: string) => {
  switch (status) {
    case 'En cours':
      return {
        icon: '🚀',
        color: 'from-blue-500 to-cyan-500',
        bgLight: 'bg-blue-50',
        textColor: 'text-blue-700',
        borderColor: 'border-blue-200'
      };
    case 'Terminé':
      return {
        icon: '✅',
        color: 'from-green-500 to-emerald-500',
        bgLight: 'bg-green-50',
        textColor: 'text-green-700',
        borderColor: 'border-green-200'
      };
    case 'Planifié':
      return {
        icon: '📅',
        color: 'from-purple-500 to-pink-500',
        bgLight: 'bg-purple-50',
        textColor: 'text-purple-700',
        borderColor: 'border-purple-200'
      };
    default:
      return {
        icon: '⏳',
        color: 'from-amber-500 to-orange-500',
        bgLight: 'bg-amber-50',
        textColor: 'text-amber-700',
        borderColor: 'border-amber-200'
      };
  }
};

const KanbanHubPage: React.FC = () => {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchProjects();
  }, []);

  const fetchProjects = async () => {
    try {
      setLoading(true);
      const response = await api.get('/projects/my-projects');
      setProjects(response.data);
      setError(null);
    } catch (err) {
      setError('Erreur lors de la récupération des projets.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col justify-center items-center min-h-screen bg-gradient-to-br from-slate-50 via-purple-50 to-indigo-50">
        <div className="relative">
          <div className="absolute inset-0 bg-purple-400 rounded-full blur-2xl opacity-30 animate-pulse"></div>
          <Loader2 className="relative h-16 w-16 animate-spin text-purple-600 mb-4" />
        </div>
        <p className="text-lg text-gray-700 font-medium">Chargement de vos projets Kanban...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-purple-50 to-indigo-50 flex items-center justify-center p-6">
        <div className="bg-red-50 border-2 border-red-200 rounded-3xl p-8 max-w-md">
          <p className="text-red-600 text-center font-semibold">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-purple-50 to-indigo-50 p-6">
      {/* Background animated elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute w-96 h-96 bg-purple-300 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse" style={{ top: '-12rem', left: '-12rem' }}></div>
        <div className="absolute w-96 h-96 bg-blue-300 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse" style={{ bottom: '-12rem', right: '-12rem' }}></div>
      </div>

      <div className="relative max-w-7xl mx-auto">
        {/* Header Section Moderne */}
        <div className="mb-12">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center shadow-lg" style={{ boxShadow: '0 8px 25px rgba(168, 85, 247, 0.4)' }}>
              <Layers className="h-6 w-6 text-white" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
              Kanban Board
            </h1>
          </div>
          <p className="text-gray-600 text-lg ml-15">Sélectionnez un sprint pour visualiser et gérer vos tâches</p>
        </div>
        
        {projects.length === 0 ? (
          <div className="text-center py-20">
            <div className="w-32 h-32 bg-gradient-to-br from-purple-100 to-pink-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <KanbanSquare className="h-16 w-16 text-purple-400" />
            </div>
            <h2 className="text-2xl font-bold text-gray-800 mb-3">Aucun projet disponible</h2>
            <p className="text-gray-600 mb-6">Créez votre premier projet pour commencer à utiliser le Kanban !</p>
            <Link to="/projects/new">
              <button className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-semibold py-3 px-8 rounded-2xl shadow-xl hover:scale-105 transition-all duration-300" style={{ boxShadow: '0 10px 40px rgba(139, 92, 246, 0.3)' }}>
                <span className="flex items-center">
                  <Sparkles className="mr-2 h-5 w-5" />
                  Créer un projet
                </span>
              </button>
            </Link>
          </div>
        ) : (
          <div className="space-y-8">
            {projects.map(project => {
              const sortedSprints = [...project.sprints].sort((a, b) => a.sprintNumber - b.sprintNumber);
              
              return (
                <div 
                  key={project.id} 
                  className="bg-white rounded-3xl p-8 border border-gray-100 shadow-xl transition-all duration-300 hover:shadow-2xl"
                  style={{ backgroundColor: 'rgba(255, 255, 255, 0.9)', backdropFilter: 'blur(16px)' }}
                >
                  {/* En-tête du projet */}
                  <div className="flex items-start justify-between mb-6 pb-6 border-b border-gray-100">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h2 className="text-3xl font-bold text-gray-900">{project.name}</h2>
                        <span className="text-xs font-semibold px-3 py-1.5 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-md">
                          {project.sprints.length} Sprint{project.sprints.length > 1 ? 's' : ''}
                        </span>
                      </div>
                      {project.description && (
                        <p className="text-gray-600 leading-relaxed">{project.description}</p>
                      )}
                    </div>

                    {/* Mini indicateur de progression */}
                    <div className="ml-6">
                      <div className="relative w-20 h-20">
                        <svg className="transform -rotate-90 w-20 h-20">
                          <circle
                            cx="40"
                            cy="40"
                            r="35"
                            stroke="rgba(147, 51, 234, 0.1)"
                            strokeWidth="6"
                            fill="none"
                          />
                          <circle
                            cx="40"
                            cy="40"
                            r="35"
                            stroke="url(#gradient-progress)"
                            strokeWidth="6"
                            fill="none"
                            strokeLinecap="round"
                            strokeDasharray={`${2 * Math.PI * 35}`}
                            strokeDashoffset={`${2 * Math.PI * 35 * (1 - project.progress / 100)}`}
                            className="transition-all duration-500"
                          />
                          <defs>
                            <linearGradient id="gradient-progress" x1="0%" y1="0%" x2="100%" y2="100%">
                              <stop offset="0%" stopColor="#6366f1" />
                              <stop offset="50%" stopColor="#a855f7" />
                              <stop offset="100%" stopColor="#ec4899" />
                            </linearGradient>
                          </defs>
                        </svg>
                        <div className="absolute inset-0 flex items-center justify-center">
                          <span className="text-sm font-bold text-gray-700">{project.progress}%</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {project.sprints.length === 0 ? (
                    <div className="text-center py-12 bg-gray-50 rounded-2xl border-2 border-dashed border-gray-200">
                      <Calendar className="h-12 w-12 text-gray-300 mx-auto mb-3" />
                      <p className="text-gray-500 font-medium">Aucun sprint défini pour ce projet</p>
                      <p className="text-gray-400 text-sm mt-1">Créez des sprints pour organiser votre travail</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {sortedSprints.map(sprint => {
                        const statusConfig = getSprintStatusConfig(sprint.status);
                        
                        return (
                          <Link 
                            key={sprint.id} 
                            to={`/projects/${project.id}/sprints/${sprint.id}/kanban`}
                            className="group"
                          >
                            <div 
                              className={`relative overflow-hidden rounded-2xl border-2 transition-all duration-300 hover:shadow-xl hover:scale-105 ${statusConfig.borderColor}`}
                              style={{ 
                                background: 'linear-gradient(135deg, rgba(255, 255, 255, 0.95) 0%, rgba(249, 245, 255, 0.95) 100%)'
                              }}
                            >
                              {/* Accent bar en haut */}
                              <div className={`h-2 bg-gradient-to-r ${statusConfig.color}`}></div>
                              
                              <div className="p-5">
                                {/* Numéro de sprint avec icône */}
                                <div className="flex items-center justify-between mb-3">
                                  <div className="flex items-center gap-2">
                                    <div className={`w-10 h-10 bg-gradient-to-br ${statusConfig.color} rounded-xl flex items-center justify-center shadow-lg`}>
                                      <span className="text-white font-bold text-sm">S{sprint.sprintNumber}</span>
                                    </div>
                                    <div>
                                      <p className="text-xs text-gray-500 font-medium">Sprint {sprint.sprintNumber}</p>
                                      <p className={`text-xs font-semibold ${statusConfig.textColor} flex items-center gap-1`}>
                                        <span>{statusConfig.icon}</span>
                                        {sprint.status}
                                      </p>
                                    </div>
                                  </div>
                                  
                                  <ArrowRight className="h-5 w-5 text-gray-400 group-hover:text-purple-600 group-hover:translate-x-1 transition-all" />
                                </div>

                                {/* Nom du sprint */}
                                <h3 className="text-lg font-bold text-gray-900 mb-3 group-hover:text-purple-600 transition-colors">
                                  {sprint.name}
                                </h3>

                                {/* Dates */}
                                <div className="space-y-2">
                                  <div className="flex items-center gap-2 text-xs text-gray-600">
                                    <Clock className="h-3.5 w-3.5 text-gray-400" />
                                    <span className="font-medium">Début:</span>
                                    <span>{new Date(sprint.startDate).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
                                  </div>
                                  <div className="flex items-center gap-2 text-xs text-gray-600">
                                    <CheckCircle className="h-3.5 w-3.5 text-gray-400" />
                                    <span className="font-medium">Fin:</span>
                                    <span>{new Date(sprint.endDate).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
                                  </div>
                                </div>

                                {/* Bouton action intégré */}
                                <div className="mt-4 pt-4 border-t border-gray-100">
                                  <div className="flex items-center justify-between">
                                    <span className="text-xs text-gray-500 font-medium">Ouvrir le tableau</span>
                                    <KanbanSquare className="h-4 w-4 text-purple-500" />
                                  </div>
                                </div>
                              </div>

                              {/* Effet hover overlay */}
                              <div className={`absolute inset-0 bg-gradient-to-br ${statusConfig.color} opacity-0 group-hover:opacity-5 transition-opacity duration-300 pointer-events-none`}></div>
                            </div>
                          </Link>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default KanbanHubPage;