import React, { useEffect, useState } from 'react';
import api from '../services/api';
import { useSse } from '../context/SseContext';
import { Loader2, Mail, Check, X } from 'lucide-react';

interface Invitation {
  id: number;
  projectName: string;
  senderName: string;
  role: string;
  sentAt: string;
}

const InvitationsPage: React.FC = () => {
  const [invitations, setInvitations] = useState<Invitation[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { clearNewInvitation } = useSse();

  useEffect(() => {
    clearNewInvitation(); // Reset notification on page load
    fetchInvitations();
  }, [clearNewInvitation]);

  const fetchInvitations = async () => {
    try {
      setLoading(true);
      const response = await api.get<Invitation[]>('/invitations/my-invitations');
      setInvitations(response.data);
      setError(null);
    } catch (err) {
      setError('Erreur lors de la récupération des invitations.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleAccept = async (invitationId: number) => {
    try {
      await api.post(`/invitations/${invitationId}/accept`);
      fetchInvitations();
    } catch (err) {
      console.error("Erreur lors de l'acceptation de l'invitation:", err);
    }
  };

  const handleDecline = async (invitationId: number) => {
    try {
      await api.post(`/invitations/${invitationId}/decline`);
      fetchInvitations();
    } catch (err) {
      console.error("Erreur lors du refus de l'invitation:", err);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen bg-gradient-to-br from-slate-50 via-purple-50 to-indigo-50">
        <Loader2 className="h-10 w-10 animate-spin text-indigo-600" />
      </div>
    );
  }

  if (error) {
    return <div className="text-center p-8 text-red-600">{error}</div>;
  }

  return (
    <div className="p-6 bg-gradient-to-br from-slate-50 via-purple-50 to-indigo-50 min-h-full">
      <h1 className="text-3xl font-bold text-gray-800 mb-8">Mes Invitations</h1>

      {invitations.length === 0 ? (
        <div className="text-center text-gray-500 py-16">
          <Mail className="mx-auto h-12 w-12 text-gray-400" />
          <p className="mt-4 text-lg">Vous n'avez aucune invitation en attente.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {invitations.map(invitation => (
            <div key={invitation.id} className="bg-white p-5 rounded-xl shadow-md flex flex-col md:flex-row md:items-center justify-between transition hover:shadow-lg">
              <div className="mb-4 md:mb-0 md:flex-1">
                <p className="text-gray-800 text-sm md:text-base">
                  <span className="font-semibold">{invitation.senderName}</span> vous a invité à rejoindre le projet <span className="font-semibold">{invitation.projectName}</span> en tant que <span className="font-semibold">{invitation.role}</span>.
                </p>
                <p className="text-gray-500 text-xs mt-1">Reçu le {new Date(invitation.sentAt).toLocaleDateString('fr-FR')}</p>
              </div>
              <div className="flex space-x-2">
                <button
                  onClick={() => handleAccept(invitation.id)}
                  className="flex items-center justify-center p-3 bg-green-500 text-white rounded-lg hover:bg-green-600 transition shadow-md"
                  title="Accepter l'invitation"
                >
                  <Check size={20} />
                </button>
                <button
                  onClick={() => handleDecline(invitation.id)}
                  className="flex items-center justify-center p-3 bg-red-500 text-white rounded-lg hover:bg-red-600 transition shadow-md"
                  title="Refuser l'invitation"
                >
                  <X size={20} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default InvitationsPage;
