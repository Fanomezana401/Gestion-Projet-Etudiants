import React, { useEffect, useState } from 'react';
import { Link, useParams, useNavigate } from 'react-router-dom';
import api from '../services/api';
import {
  Loader2,
  KanbanSquare,
  Calendar,
  Flag,
  MessageSquare,
  Edit,
  Trash2,
  PlusCircle,
  ArrowLeft,
  Activity,
  Target,
  Clock
} from 'lucide-react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';

/* ===================== TYPES ===================== */
interface Sprint {
  id: number;
  name: string;
  sprintNumber: number;
  startDate: string;
  endDate: string;
  status: string;
}

interface Project {
  id: number;
  name: string;
  description: string;
  progress: number;
  status: string;
  sprints: Sprint[];
}

/* ===================== SCHEMAS ===================== */
const editProjectSchema = z.object({
  name: z.string().min(3),
  description: z.string().optional(),
  status: z.string(),
});
type EditProjectFormInputs = z.infer<typeof editProjectSchema>;

const sprintSchema = z.object({
  name: z.string().min(3),
  startDate: z.string(),
  endDate: z.string(),
  status: z.string().optional(),
});
type SprintFormInputs = z.infer<typeof sprintSchema>;

/* ===================== HELPERS ===================== */
const getStatusColor = (status: string) => {
  switch (status) {
    case 'Terminé': return 'from-green-500 to-emerald-500';
    case 'Actif':
    case 'En cours': return 'from-blue-500 to-cyan-500';
    default: return 'from-purple-500 to-pink-500';
  }
};

/* ===================== COMPONENT ===================== */
const ProjectDetailPage: React.FC = () => {
  const { projectId } = useParams<{ projectId: string }>();
  const navigate = useNavigate();

  const [project, setProject] = useState<Project | null>(null);
  const [loading, setLoading] = useState(true);
  const [showEditProjectModal, setShowEditProjectModal] = useState(false);
  const [showSprintModal, setShowSprintModal] = useState(false);
  const [currentSprint, setCurrentSprint] = useState<Sprint | null>(null);

  const circumference = 2 * Math.PI * 52;

  const {
    register: registerProject,
    handleSubmit: handleProjectSubmit,
    reset: resetProjectForm,
  } = useForm<EditProjectFormInputs>({
    resolver: zodResolver(editProjectSchema),
  });

  const {
    register: registerSprint,
    handleSubmit: handleSprintSubmit,
    reset: resetSprintForm,
  } = useForm<SprintFormInputs>({
    resolver: zodResolver(sprintSchema),
  });

  useEffect(() => {
    fetchProject();
  }, [projectId]);

  const fetchProject = async () => {
    if (!projectId) return;
    setLoading(true);
    const res = await api.get<Project>(`/projects/${projectId}`);
    setProject(res.data);
    setLoading(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 via-purple-50 to-indigo-50">
        <Loader2 className="h-14 w-14 animate-spin text-purple-600" />
      </div>
    );
  }

  if (!project) return null;

  const completedSprints = project.sprints.filter(s => s.status === 'Terminé').length;
  const sprintRate = project.sprints.length
    ? (completedSprints / project.sprints.length) * 100
    : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-purple-50 to-indigo-50 p-6">
      <div className="max-w-7xl mx-auto space-y-8">

        {/* ===== HEADER ===== */}
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate(-1)}
            className="p-3 rounded-xl bg-white shadow hover:scale-105 transition"
          >
            <ArrowLeft />
          </button>
          <div>
            <h1 className="text-4xl font-extrabold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              {project.name}
            </h1>
            <p className="text-gray-600">{project.description}</p>
          </div>
        </div>

        {/* ===== KPI CARDS ===== */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">

          {/* Progress circle */}
          <div className="bg-white rounded-3xl p-6 shadow-xl">
            <div className="flex items-center gap-3 mb-4">
              <Target className="text-purple-600" />
              <h3 className="text-xl font-bold">Progression</h3>
            </div>

            <div className="relative w-32 h-32 mx-auto">
              <svg className="-rotate-90 w-32 h-32">
                <circle
                  cx="64"
                  cy="64"
                  r="52"
                  stroke="#eee"
                  strokeWidth="10"
                  fill="none"
                />
                <circle
                  cx="64"
                  cy="64"
                  r="52"
                  stroke="url(#grad)"
                  strokeWidth="10"
                  fill="none"
                  strokeLinecap="round"
                  strokeDasharray={circumference}
                  strokeDashoffset={circumference * (1 - project.progress / 100)}
                />
                <defs>
                  <linearGradient id="grad">
                    <stop offset="0%" stopColor="#a855f7" />
                    <stop offset="100%" stopColor="#ec4899" />
                  </linearGradient>
                </defs>
              </svg>
              <div className="absolute inset-0 flex items-center justify-center flex-col">
                <span className="text-3xl font-black">{project.progress}%</span>
                <span className="text-xs text-gray-500">Complété</span>
              </div>
            </div>
          </div>

          {/* Status */}
          <div className="bg-white rounded-3xl p-6 shadow-xl">
            <div className="flex items-center gap-3 mb-4">
              <Activity className="text-indigo-600" />
              <h3 className="text-xl font-bold">Statut</h3>
            </div>
            <div className={`inline-flex px-4 py-2 rounded-full text-white font-semibold bg-gradient-to-r ${getStatusColor(project.status)}`}>
              {project.status}
            </div>
          </div>

          {/* Sprints */}
          <div className="bg-white rounded-3xl p-6 shadow-xl">
            <div className="flex items-center gap-3 mb-4">
              <Clock className="text-pink-600" />
              <h3 className="text-xl font-bold">Sprints</h3>
            </div>
            <p className="text-4xl font-black">{project.sprints.length}</p>
            <p className="text-gray-500">Dont {completedSprints} terminés</p>
            <div className="mt-3 h-2 bg-gray-200 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-purple-500 to-pink-500"
                style={{ width: `${sprintRate}%` }}
              />
            </div>
          </div>
        </div>

        {/* ===== ACTIONS ===== */}
        <div className="flex gap-4 flex-wrap">
          <Link to={`/messages/${project.id}`} className="btn-primary">
            <MessageSquare className="mr-2" /> Messages
          </Link>
          <button onClick={() => {
            resetProjectForm(project);
            setShowEditProjectModal(true);
          }} className="btn-secondary">
            <Edit className="mr-2" /> Modifier
          </button>
          <button
            onClick={() => {
              if (confirm('Supprimer ce projet ?')) {
                api.delete(`/projects/${project.id}`).then(() => navigate('/projects'));
              }
            }}
            className="btn-danger"
          >
            <Trash2 className="mr-2" /> Supprimer
          </button>
        </div>

        {/* ===== SPRINT LIST ===== */}
        <div className="bg-white rounded-3xl p-6 shadow-xl">
          <div className="flex justify-between mb-6">
            <h2 className="text-2xl font-bold">Sprints</h2>
            <button
              onClick={() => {
                setCurrentSprint(null);
                resetSprintForm();
                setShowSprintModal(true);
              }}
              className="btn-primary"
            >
              <PlusCircle className="mr-2" /> Ajouter
            </button>
          </div>

          <div className="space-y-4">
            {project.sprints.map(sprint => (
              <div key={sprint.id} className="p-4 border rounded-xl flex justify-between items-center">
                <div>
                  <h4 className="font-bold">{sprint.name}</h4>
                  <p className="text-sm text-gray-500 flex items-center gap-1">
                    <Calendar size={14} />
                    {new Date(sprint.startDate).toLocaleDateString()} → {new Date(sprint.endDate).toLocaleDateString()}
                  </p>
                </div>
                <Link
                  to={`/projects/${project.id}/sprints/${sprint.id}/kanban`}
                  className="btn-secondary"
                >
                  <KanbanSquare className="mr-2" /> Kanban
                </Link>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};

export default ProjectDetailPage;
