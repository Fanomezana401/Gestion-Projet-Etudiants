import React, { useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { AuthContext } from '../context/AuthContext';
import api from '../services/api';
import { UserPlus, Mail, Lock, User, Sparkles } from 'lucide-react';

const registerSchema = z.object({
  firstname: z.string().min(1, { message: 'Le prénom est requis' }),
  lastname: z.string().min(1, { message: 'Le nom est requis' }),
  email: z.string().email({ message: 'Adresse email invalide' }),
  password: z.string().min(6, { message: 'Le mot de passe doit contenir au moins 6 caractères' }),
  role: z.enum(['STUDENT', 'TEACHER'], { message: 'Veuillez sélectionner un rôle valide' }),
});

type RegisterFormInputs = z.infer<typeof registerSchema>;

const RegisterPage: React.FC = () => {
  const authContext = useContext(AuthContext);
  const navigate = useNavigate();
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
    setError,
  } = useForm<RegisterFormInputs>({
    resolver: zodResolver(registerSchema),
  });

  if (!authContext) return null;
  const { login } = authContext;

  const onSubmit = async (data: RegisterFormInputs) => {
    try {
      const response = await api.post('/auth/register', data);
      login(response.data.token);
      navigate('/dashboard');
    } catch (err: any) {
      setError('root', {
        type: 'manual',
        message: err.response?.data?.message || "Une erreur s'est produite lors de l'inscription.",
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center p-4">
      {/* Animated background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute w-96 h-96 -top-48 -left-48 bg-purple-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse"></div>
        <div className="absolute w-96 h-96 -bottom-48 -right-48 bg-blue-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse"></div>
      </div>

      <div className="relative w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-block mb-4 px-4 py-2 bg-purple-500/20 backdrop-blur-sm rounded-full border border-purple-400/30">
            <span className="text-purple-300 text-sm font-medium flex items-center gap-2">
              <Sparkles className="h-4 w-4" />
              Rejoignez la communauté
            </span>
          </div>
          <h2 className="text-4xl font-bold bg-gradient-to-r from-purple-400 via-pink-300 to-blue-400 bg-clip-text text-transparent mb-2">
            Inscription
          </h2>
          <p className="text-gray-400">Créez votre compte pour commencer</p>
        </div>

        {/* Form */}
        <div className="bg-white/5 backdrop-blur-xl p-8 rounded-2xl border border-white/10 shadow-2xl">
          <form className="space-y-5" onSubmit={handleSubmit(onSubmit)}>
            {errors.root && (
              <div className="p-4 text-sm text-red-300 bg-red-500/10 rounded-xl border border-red-500/20 backdrop-blur-sm">
                {errors.root.message}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="firstname" className="block mb-2 font-medium text-gray-300">Prénom</label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <input
                    id="firstname"
                    {...register('firstname')}
                    type="text"
                    placeholder="Votre prénom"
                    className={`w-full pl-10 pr-4 py-3 bg-white/5 border rounded-xl text-white placeholder-gray-500 backdrop-blur-sm focus:outline-none focus:ring-2 transition-all duration-300 ${
                      errors.firstname 
                        ? 'border-red-500/50 focus:ring-red-500/50 focus:border-red-500' 
                        : 'border-white/10 focus:ring-purple-500/50 focus:border-purple-500 hover:border-white/20'
                    }`}
                  />
                </div>
                {errors.firstname && <p className="mt-2 text-sm text-red-400">{errors.firstname.message}</p>}
              </div>

              <div>
                <label htmlFor="lastname" className="block mb-2 font-medium text-gray-300">Nom</label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <input
                    id="lastname"
                    {...register('lastname')}
                    type="text"
                    placeholder="Votre nom"
                    className={`w-full pl-10 pr-4 py-3 bg-white/5 border rounded-xl text-white placeholder-gray-500 backdrop-blur-sm focus:outline-none focus:ring-2 transition-all duration-300 ${
                      errors.lastname 
                        ? 'border-red-500/50 focus:ring-red-500/50 focus:border-red-500' 
                        : 'border-white/10 focus:ring-purple-500/50 focus:border-purple-500 hover:border-white/20'
                    }`}
                  />
                </div>
                {errors.lastname && <p className="mt-2 text-sm text-red-400">{errors.lastname.message}</p>}
              </div>
            </div>

            <div>
              <label htmlFor="email" className="block mb-2 font-medium text-gray-300">Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <input
                  id="email"
                  {...register('email')}
                  type="email"
                  placeholder="votre.email@exemple.com"
                  className={`w-full pl-10 pr-4 py-3 bg-white/5 border rounded-xl text-white placeholder-gray-500 backdrop-blur-sm focus:outline-none focus:ring-2 transition-all duration-300 ${
                    errors.email 
                      ? 'border-red-500/50 focus:ring-red-500/50 focus:border-red-500' 
                      : 'border-white/10 focus:ring-purple-500/50 focus:border-purple-500 hover:border-white/20'
                  }`}
                />
              </div>
              {errors.email && <p className="mt-2 text-sm text-red-400">{errors.email.message}</p>}
            </div>

            <div>
              <label htmlFor="password" className="block mb-2 font-medium text-gray-300">Mot de passe</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <input
                  id="password"
                  {...register('password')}
                  type="password"
                  placeholder="••••••••"
                  className={`w-full pl-10 pr-4 py-3 bg-white/5 border rounded-xl text-white placeholder-gray-500 backdrop-blur-sm focus:outline-none focus:ring-2 transition-all duration-300 ${
                    errors.password 
                      ? 'border-red-500/50 focus:ring-red-500/50 focus:border-red-500' 
                      : 'border-white/10 focus:ring-purple-500/50 focus:border-purple-500 hover:border-white/20'
                  }`}
                />
              </div>
              {errors.password && <p className="mt-2 text-sm text-red-400">{errors.password.message}</p>}
            </div>

            <div>
              <label htmlFor="role" className="block mb-2 font-medium text-gray-300">Je suis un...</label>
              <select
                id="role"
                {...register('role')}
                className={`w-full px-4 py-3 bg-white/5 border rounded-xl text-white placeholder-gray-500 backdrop-blur-sm focus:outline-none focus:ring-2 transition-all duration-300 ${
                  errors.role 
                    ? 'border-red-500/50 focus:ring-red-500/50 focus:border-red-500' 
                    : 'border-white/10 focus:ring-purple-500/50 focus:border-purple-500 hover:border-white/20'
                }`}
              >
                <option value="" className="bg-slate-800">Sélectionner un rôle</option>
                <option value="STUDENT" className="bg-slate-800">Étudiant</option>
                <option value="TEACHER" className="bg-slate-800">Professeur</option>
              </select>
              {errors.role && <p className="mt-2 text-sm text-red-400">{errors.role.message}</p>}
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="group w-full py-3 text-white font-semibold bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl shadow-2xl hover:shadow-purple-500/50 transform hover:scale-105 transition-all duration-300 disabled:opacity-50 disabled:scale-100 disabled:cursor-not-allowed relative overflow-hidden"
            >
              <span className="relative z-10 flex items-center justify-center">
                <UserPlus className="mr-2 h-5 w-5" />
                {isSubmitting ? "Inscription..." : "S'inscrire"}
              </span>
            </button>
          </form>

          <p className="text-center text-gray-400 mt-6">
            Déjà un compte ?{' '}
            <Link to="/login" className="text-purple-400 hover:text-purple-300 font-medium transition-colors">
              Connectez-vous
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default RegisterPage;
