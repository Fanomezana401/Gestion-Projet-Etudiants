import React, { useEffect, useState } from "react";

interface TaskModalProps {
  isOpen: boolean;
  task?: { content: string } | null;
  onSave: (content: string) => void;
  onClose: () => void;
}

const TaskModal: React.FC<TaskModalProps> = ({ isOpen, task, onSave, onClose }) => {
  const [content, setContent] = useState("");

  useEffect(() => {
    setContent(task?.content || "");
  }, [task, isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-white/90 backdrop-blur-xl rounded-2xl p-6 w-96 shadow-2xl border border-gray-200">
        <h2 className="text-2xl font-bold mb-4 text-gray-800">{task ? "Modifier la tâche" : "Nouvelle tâche"}</h2>
        
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="Contenu de la tâche..."
          className="w-full px-4 py-3 rounded-xl border border-gray-300/50 bg-white/20 placeholder-gray-400 text-gray-800 focus:outline-none focus:ring-2 focus:ring-indigo-400 focus:border-indigo-400 backdrop-blur-sm transition-all duration-300 resize-none"
          rows={5}
        />

        <div className="flex justify-end gap-3 mt-4">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-gray-200 hover:bg-gray-300 text-gray-700 font-medium transition-all duration-300"
          >
            Annuler
          </button>
          <button
            onClick={() => { if (content.trim()) onSave(content); }}
            className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold transition-all duration-300"
          >
            Enregistrer
          </button>
        </div>
      </div>
    </div>
  );
};

export default TaskModal;
