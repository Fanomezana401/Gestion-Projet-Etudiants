import React from "react";

export default function ProjectList() {
  const projects = [
    { id: "1", title: "Projet A", description: "Description A", status: "todo" },
    { id: "2", title: "Projet B", description: "Description B", status: "in_progress" },
  ];

  const statusStyles: Record<string, string> = {
    todo: "bg-yellow-100 text-yellow-800",
    in_progress: "bg-blue-100 text-blue-800",
    done: "bg-green-100 text-green-800",
  };

  const statusLabels: Record<string, string> = {
    todo: "À faire",
    in_progress: "En cours",
    done: "Terminé",
  };

  return (
    <div className="grid gap-6 md:grid-cols-2">
      {projects.map((p) => (
        <div
          key={p.id}
          className="bg-white dark:bg-gray-800 p-5 rounded-2xl shadow-md hover:shadow-lg transition flex flex-col sm:flex-row justify-between items-start sm:items-center"
        >
          <div className="flex-1">
            <h3 className="text-lg font-bold text-gray-800 dark:text-gray-100">{p.title}</h3>
            <p className="text-gray-600 dark:text-gray-300 text-sm mt-1">{p.description}</p>
            <span
              className={`mt-3 inline-block px-3 py-1 rounded-full text-xs font-medium ${statusStyles[p.status]}`}
            >
              {statusLabels[p.status]}
            </span>
          </div>

          <div className="flex gap-3 mt-4 sm:mt-0">
            <button className="px-4 py-2 rounded-xl bg-indigo-100 text-indigo-700 hover:bg-indigo-200 transition">
              Éditer
            </button>
            <button className="px-4 py-2 rounded-xl bg-red-100 text-red-700 hover:bg-red-200 transition">
              Supprimer
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
