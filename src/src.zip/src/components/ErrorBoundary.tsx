import React from "react";

type State = { hasError: boolean; error?: Error };

export default class ErrorBoundary extends React.Component<{}, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error: Error, info: any) {
    console.error("Captured by ErrorBoundary:", error, info);
  }

  handleReload = () => {
    this.setState({ hasError: false });
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="flex flex-col justify-center items-center min-h-screen bg-gray-50 p-8">
          <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-8 text-center max-w-md">
            <h1 className="text-2xl font-bold text-red-600 mb-4">Oups… Une erreur est survenue</h1>
            <p className="text-gray-700 mb-6">
              Quelque chose a mal tourné. Regarde la console pour plus de détails.
            </p>
            <button
              onClick={this.handleReload}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg shadow transition duration-300"
            >
              Recharger la page
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
