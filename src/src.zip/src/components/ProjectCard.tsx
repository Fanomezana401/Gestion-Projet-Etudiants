import React from "react";
import { Edit, Trash2 } from "lucide-react";

export default function ProjectCard({
  project,
  onEdit,
  onDelete,
}: {
  project: any;
  onEdit: (p: any) => void;
  onDelete: (id: string) => void;
}) {
  return (
    <div className="bg-white dark:bg-gray-800 p-5 rounded-2xl shadow-md hover:shadow-lg transition flex flex-col sm:flex-row justify-between items-start sm:items-center">
      <div className="flex-1">
        <h3 className="text-lg font-bold text-gray-800 dark:text-gray-100">{project.name}</h3>
        <p className="text-gray-600 dark:text-gray-300 text-sm mt-1">{project.description}</p>
      </div>

      <div className="flex gap-3 mt-4 sm:mt-0">
        <button
          onClick={() => onEdit(project)}
          className="flex items-center justify-center px-3 py-2 rounded-xl bg-yellow-100 text-yellow-700 hover:bg-yellow-200 transition"
        >
          <Edit size={16} />
        </button>
        <button
          onClick={() => onDelete(project.id)}
          className="flex items-center justify-center px-3 py-2 rounded-xl bg-red-100 text-red-700 hover:bg-red-200 transition"
        >
          <Trash2 size={16} />
        </button>
      </div>
    </div>
  );
}
