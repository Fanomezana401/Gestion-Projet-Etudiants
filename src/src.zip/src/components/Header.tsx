import React, { useState } from "react";
import { PlusCircle, Bell, User } from "lucide-react";

interface HeaderProps {
  onCreateProject: () => void;
}

export default function Header({ onCreateProject }: HeaderProps) {
  const [openMenu, setOpenMenu] = useState(false);

  return (
    <header className="flex justify-between items-center bg-white dark:bg-gray-800 p-4 shadow-md rounded-2xl mb-6">
      <h1 className="text-2xl font-bold text-gray-800 dark:text-gray-100">Gestion des projets</h1>

      <div className="flex items-center gap-4">
        {/* Bouton créer projet */}
        <button
          onClick={onCreateProject}
          className="flex items-center gap-2 px-5 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-semibold rounded-xl shadow-md hover:from-indigo-700 hover:to-purple-700 transition duration-300"
        >
          <PlusCircle size={20} />
          Nouveau projet
        </button>

        {/* Notification */}
        <button className="relative p-3 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition duration-200">
          <Bell size={20} />
          <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full border-2 border-white dark:border-gray-800"></span>
        </button>

        {/* Menu utilisateur */}
        <div className="relative">
          <button
            onClick={() => setOpenMenu(!openMenu)}
            className="flex items-center gap-2 p-3 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition duration-200"
          >
            <User size={20} />
          </button>

          {openMenu && (
            <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-800 shadow-lg rounded-2xl overflow-hidden z-50 border border-gray-200 dark:border-gray-700">
              <button className="block w-full text-left px-4 py-3 hover:bg-gray-100 dark:hover:bg-gray-700 transition">Profil</button>
              <button className="block w-full text-left px-4 py-3 hover:bg-gray-100 dark:hover:bg-gray-700 transition">Paramètres</button>
              <button className="block w-full text-left px-4 py-3 hover:bg-gray-100 dark:hover:bg-gray-700 transition text-red-600 font-semibold">Déconnexion</button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
