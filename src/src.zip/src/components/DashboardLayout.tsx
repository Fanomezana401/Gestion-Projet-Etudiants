// src/pages/Dashboard.tsx
import React, { useState } from "react";
import Sidebar from "../components/Sidebar";
import ProjectCard from "../components/ProjectCard";
import ProjectModal from "../components/ProjectModal";
import { Project } from "../components/types";
import KanbanBoard from "../components/KanbanBoard";
import { useAuth } from "../context/AuthContext";

export default function Dashboard() {
  const { user } = useAuth();
  const [projects, setProjects] = useState<Project[]>([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingProject, setEditingProject] = useState<Project | undefined>(undefined);

  const openModal = (project?: Project) => {
    setEditingProject(project);
    setModalOpen(true);
  };

  const saveProject = (project: Project) => {
    setProjects((prev) => {
      const exists = prev.find((p) => p.id === project.id);
      return exists ? prev.map((p) => (p.id === project.id ? project : p)) : [...prev, project];
    });
    setModalOpen(false);
  };

  const deleteProject = (id: string) => setProjects((prev) => prev.filter((p) => p.id !== id));

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar role={user!.role} />

      <div className="flex-1 p-6 overflow-auto">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold text-gray-800">
            {user?.role === "teacher" ? "Projets à gérer" : "Mes projets"}
          </h1>
          <button
            onClick={() => openModal()}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg shadow transition duration-300"
          >
            + Nouveau projet
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((p) => (
            <ProjectCard key={p.id} project={p} onEdit={openModal} onDelete={deleteProject} />
          ))}
        </div>

        <h2 className="text-2xl font-bold mt-10 mb-4 text-gray-800">Kanban</h2>
        <div className="bg-white rounded-2xl shadow p-4">
          <KanbanBoard />
        </div>
      </div>

      {modalOpen && (
        <ProjectModal
          isOpen={modalOpen}
          project={editingProject}
          onSave={saveProject}
          onClose={() => setModalOpen(false)}
        />
      )}
    </div>
  );
}
