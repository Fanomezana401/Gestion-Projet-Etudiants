import React, { useState } from "react";
import { Home, Folder, User, Moon, Sun } from "lucide-react";

export default function Sidebar() {
  const [darkMode, setDarkMode] = useState(false);

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    document.documentElement.classList.toggle("dark");
  };

  const navItems = [
    { label: "Tableau de bord", icon: <Home size={20} /> },
    { label: "Projets", icon: <Folder size={20} /> },
    { label: "Profil", icon: <User size={20} /> },
  ];

  return (
    <aside className="w-64 bg-white dark:bg-gray-900 shadow-2xl flex flex-col p-6">
      <div className="text-3xl font-bold mb-8 text-indigo-600 text-center">
        ProjManager
      </div>

      <nav className="flex-1 flex flex-col gap-4">
        {navItems.map((item) => (
          <button
            key={item.label}
            className="flex items-center gap-3 p-3 rounded-2xl text-gray-700 dark:text-gray-200 hover:bg-indigo-50 dark:hover:bg-indigo-800 transition-colors duration-300 font-medium"
          >
            {item.icon}
            {item.label}
          </button>
        ))}
      </nav>

      <div className="mt-6 flex justify-center">
        <button
          onClick={toggleDarkMode}
          className="p-3 rounded-full bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 transition flex items-center justify-center"
        >
          {darkMode ? <Sun size={20} /> : <Moon size={20} />}
        </button>
      </div>
    </aside>
  );
}
