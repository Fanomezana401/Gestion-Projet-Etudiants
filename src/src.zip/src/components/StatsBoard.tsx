import React from "react";

export default function StatsBoard() {
  const stats = { todo: 3, in_progress: 5, done: 2 };

  const cards = [
    { label: "À faire", value: stats.todo, color: "from-yellow-200 to-yellow-300" },
    { label: "En cours", value: stats.in_progress, color: "from-blue-200 to-blue-300" },
    { label: "Terminé", value: stats.done, color: "from-green-200 to-green-300" },
  ];

  return (
    <div className="grid md:grid-cols-3 gap-6">
      {cards.map((card) => (
        <div
          key={card.label}
          className={`bg-gradient-to-br ${card.color} p-6 rounded-2xl shadow-2xl text-center transform hover:scale-105 transition-transform duration-300`}
        >
          <h3 className="text-lg font-semibold text-gray-700">{card.label}</h3>
          <p className="text-4xl font-bold text-gray-900 mt-2">{card.value}</p>
        </div>
      ))}
    </div>
  );
}
