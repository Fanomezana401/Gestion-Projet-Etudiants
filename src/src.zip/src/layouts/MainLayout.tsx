import React, { useContext, useMemo } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import { useSse } from '../context/SseContext';
import { LayoutDashboard, Folder, ListTodo, MessageSquare, BarChart2, LogOut, Mail } from 'lucide-react';

const NavItem: React.FC<{ to: string; icon: React.ReactNode; label: string; notificationCount?: number }> = ({ to, icon, label, notificationCount }) => {
  return (
    <NavLink
      to={to}
      className={({ isActive }) =>
        `flex items-center py-3 px-4 rounded-xl transition-all duration-300 mb-2 font-medium ${
          isActive
            ? 'bg-gradient-to-r from-indigo-100 via-purple-50 to-pink-50 text-indigo-600 shadow-inner'
            : 'text-gray-700 hover:bg-indigo-50 hover:text-indigo-600'
        }`
      }
    >
      {icon}
      <span className="flex-1 ml-2">{label}</span>
      {notificationCount && notificationCount > 0 && (
        <span className="ml-2 bg-red-500 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center animate-pulse">
          {notificationCount}
        </span>
      )}
    </NavLink>
  );
};

const MainLayout: React.FC = () => {
  const authContext = useContext(AuthContext);
  const { projectUnreadCounts, newInvitation } = useSse();
  const navigate = useNavigate();

  const totalUnreadMessages = useMemo(() => {
    return Array.from(projectUnreadCounts.values()).reduce((acc, count) => acc + count, 0);
  }, [projectUnreadCounts]);

  if (!authContext) return null;
  const { logout } = authContext;

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="flex h-screen font-sans bg-gray-50">
      {/* Sidebar */}
      <aside className="w-72 bg-white/90 backdrop-blur-xl shadow-xl flex flex-col p-6 border-r border-gray-200">
        <h1 className="text-2xl font-bold mb-6 text-indigo-600">
          <NavLink to="/dashboard" className="flex items-center">
            <LayoutDashboard className="mr-2 h-6 w-6" /> Gestion Projets
          </NavLink>
        </h1>

        <nav className="flex-1">
          <NavItem to="/dashboard" icon={<LayoutDashboard className="h-5 w-5" />} label="Tableau de Bord" />
          <NavItem to="/projects" icon={<Folder className="h-5 w-5" />} label="Mes Projets" />
          <NavItem to="/tasks" icon={<ListTodo className="h-5 w-5" />} label="Tâches (Kanban)" />
          <NavItem
            to="/messages"
            icon={<MessageSquare className="h-5 w-5" />}
            label="Messagerie"
            notificationCount={totalUnreadMessages}
          />
          <NavItem
            to="/invitations"
            icon={<Mail className="h-5 w-5" />}
            label="Invitations"
            notificationCount={newInvitation ? 1 : 0}
          />
          <NavItem to="/stats" icon={<BarChart2 className="h-5 w-5" />} label="Statistiques" />
        </nav>

        {/* Logout */}
        <div className="mt-auto">
          <button
            onClick={handleLogout}
            className="w-full flex items-center py-3 px-4 rounded-xl hover:bg-red-50 text-red-600 hover:text-red-700 transition-all duration-300 font-medium shadow-sm"
          >
            <LogOut className="mr-2 h-5 w-5" /> Déconnexion
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-6 overflow-auto bg-gray-50">
        <Outlet />
      </main>
    </div>
  );
};

export default MainLayout;
